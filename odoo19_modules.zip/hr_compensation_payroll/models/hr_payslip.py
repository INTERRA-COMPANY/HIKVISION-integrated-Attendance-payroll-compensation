import logging
import re
from collections import defaultdict

from odoo import Command, api, fields, models
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)

FIXED_CODE = 'COMP_FIXED'
RULE_FIELD_RE = re.compile(r'\b(version|contract|employee)\.([A-Za-z_]\w*)')
ALLOWANCE_PREFIX = 'ALW_'
DEFAULT_SEQUENCE = 120
EDITABLE_STATES = ('draft', 'verify')
# rule parameters: code -> (name, value). Changed by date in Payroll > Configuration > Rule Parameters.
PARAMETERS = {
    'payroll_month_days': ('Days per Month (daily rate)', 30),
    'payroll_day_hours': ('Hours per Day (hourly rate)', 8),
    'payroll_si_employee_rate': ('Social Insurance - Employee Share (%)', 11),
    'payroll_si_company_rate': ('Social Insurance - Company Share (%)', 18.75),
    'payroll_si_min_wage': ('Social Insurance - Minimum Insurable Wage (0 = none)', 0),
    'payroll_si_max_wage': ('Social Insurance - Maximum Insurable Wage (0 = none)', 0),
}
# rules of the Egyptian structures, by code
INSURANCE_RULES = {'SIEMP': ('payroll_si_employee_rate', -1), 'SICOMP': ('payroll_si_company_rate', 1)}
TAX_RULES = ('GROSSY', 'TAXBLEAM', 'TOTTB')
ABSENCE_RULES = ('EGLEAVE90', 'EGSICKLEAVE75', 'EGSICKLEAVE0')
# rules paid from the employee card: code -> (name, flag, amount field, category, sign)
EMPLOYEE_RULES = {
    'LIFE_INS': ('Life Insurance', 'life_insurance', 'life_insurance_amount', 'COMP', 1),
    'MEDICAL_INS': ('Medical Insurance', 'medical_insurance', 'medical_insurance_amount', 'COMP', 1),
    'STAMP_TAX': ('Stamp Tax', 'stamp_tax', 'stamp_tax_amount', 'DED', -1),
}
# chart of accounts of the company, filled once in the empty accounts of the rules of the structures named
# Yard (operations) / Office (administration). rule code -> (debit Yard, debit Office, credit Yard, credit Office).
# A deduction is a negative amount: Odoo credits its debit account and debits its credit account.
ACCOUNTS = {
    'BASIC': ('400001', '400013', None, None),
    'TA': ('400002', '400014', None, None),
    'MEAL': ('400003', '400015', None, None),
    'HOU': ('400004', '400016', None, None),
    'FIXED': ('400005', '400017', None, None),
    'VAR': ('400006', '400018', None, None),
    'HIK_OT_WORKDAY': ('400007', '400019', None, None),
    'HIK_OT_WEEKLY': ('400008', '400020', None, None),
    'HIK_OT_HOLIDAY': ('400009', '400021', None, None),
    'HIK_ABSENCE': ('400010', '400022', None, None),
    'EGLEAVE90': ('400010', '400022', None, None),
    'HIK_LATE': ('400011', '400023', None, None),
    'OUT': ('400012', '400076', None, None),
    'SICOMP': ('400025', '400025', '201026', '201026'),
    'SIEMP': ('201026', '201026', None, None),
    'TOTTB': ('201027', '201027', None, None),
    'LOAN': ('102004', '102005', None, None),
}
# the net is the credit side: one net rule per payslip kind, each in its accrued account (Pay reconciles it)
NET_ACCOUNTS = {'salary': ('201001', '201002'), 'overtime': ('201003', '201004')}
# credits set on the lines by the previous version, moved to the nets
ACCRUED_CODES = ('201001', '201002', '201003', '201004', '201005', '201006')
STRUCTURE_SIDES = {'Yard': 0, 'Office': 1}
ABSENCE_BASE_RE = re.compile(r"\(\s*categories\['BASIC'\]\s*\+\s*categories\['BASICALW'\]\s*\)"
                             r"|categories\['BASIC'\]\s*\+\s*categories\['BASICALW'\]")


class HrAllowanceType(models.Model):
    _inherit = 'hr.allowance.type'

    payroll_rule_code = fields.Char(
        'Salary Rule Code',
        help='Code of the salary rule that pays this allowance, e.g. MEAL for the Egyptian structure. '
             'An existing rule with this code keeps its category and position, and reads its amount from here. '
             'Empty: a new rule ALW_<code> is created.')

    def _payroll_code(self):
        """Code of the payslip input carrying the amount."""
        self.ensure_one()
        return ALLOWANCE_PREFIX + self.code

    def _payroll_input_type(self):
        """Payslip input type of this allowance, created on first use."""
        self.ensure_one()
        InputType = self.env['hr.payslip.input.type'].sudo()
        code = self._payroll_code()
        return InputType.search([('code', '=', code)], limit=1) or InputType.create({'name': self.name, 'code': code})



class HrSalaryRule(models.Model):
    _inherit = 'hr.salary.rule'

    comp_input_code = fields.Char(
        'Amount From Compensation', readonly=True, copy=False,
        help='This rule is paid from the Compensation tab of the employee (payslip input with this code).')
    comp_original_condition = fields.Text('Original Condition', readonly=True, copy=False)
    comp_original_amount = fields.Text('Original Python Code', readonly=True, copy=False)
    payroll_net_for = fields.Selection(
        [('salary', 'Salary Payslips'), ('overtime', 'Overtime Payslips')], string='Net Of',
        help='Two net rules (code NET) in the structure: the net of the salary payslips (also of the payslips '
             'paying salary + overtime) and the net of the separate overtime payslips, each with its account.')

    def _comp_keep_original(self):
        """Keep the original code of rules about to be changed (once: the first original is kept)."""
        for rule in self:
            rule.write({
                'comp_original_condition': rule.comp_original_condition or (
                    f'{rule.condition_select}: {rule.condition_python or ""}'),
                'comp_original_amount': rule.comp_original_amount or (
                    f'{rule.amount_select}: {rule.amount_python_compute or ""}'),
            })

    def _comp_take_over(self, input_code):
        """Make an existing rule read its amount from a compensation payslip input (kept once: re-runs are no-ops)."""
        for rule in self.filtered(lambda r: r.comp_input_code != input_code):
            rule._comp_keep_original()
            rule.write({
                'comp_input_code': input_code,
                'condition_select': 'python',
                'condition_python': f"result = '{input_code}' in inputs",
                'amount_select': 'code',
                'amount_python_compute': f"result = inputs['{input_code}'].amount",
            })

    def _satisfy_condition(self, localdict):
        """Compute Salary leaves the overtime rules out, Compute Overtime keeps only them and the net."""
        slip = localdict.get('payslip')
        slip = getattr(slip, 'dict', slip)
        mode = slip.payroll_mode if isinstance(slip, models.BaseModel) and 'payroll_mode' in slip._fields else 'all'
        if self.code == 'NET' and self.payroll_net_for and \
                (mode == 'overtime') != (self.payroll_net_for == 'overtime'):
            return False
        if mode != 'all':
            if '_payroll_overtime_codes' not in localdict:
                localdict['_payroll_overtime_codes'] = slip._payroll_overtime_codes()
            overtime = self.code in localdict['_payroll_overtime_codes']
            if mode == 'salary' and overtime:
                return False
            # by code only: other rules of the net category (e.g. GROSSY) need the salary rules left out here
            if mode == 'overtime' and not overtime and self.code != 'NET':
                return False
        return super()._satisfy_condition(localdict)


class HrPayslip(models.Model):
    _inherit = 'hr.payslip'

    payroll_mode = fields.Selection([
        ('all', 'Salary + Overtime'),
        ('salary', 'Salary Only'),
        ('overtime', 'Overtime Only'),
    ], string='Computed As', default='all', required=True, readonly=True, copy=False,
        help='Set by the buttons Compute Salary + Overtime, Compute Salary and Compute Overtime.')
    payroll_adjustment_ids = fields.One2many('hr.comp.adjustment', 'payslip_id', string='Manual Amounts')

    # ---------------------------------------------------------------- helpers used by the salary rules
    @api.model
    def _payroll_parameter_defaults(self):
        return {code: value for code, (_name, value) in PARAMETERS.items()}

    def _payroll_param(self, code):
        """Rule parameter at the payslip date (Payroll > Configuration > Rule Parameters), default if missing."""
        try:
            return self._rule_parameter(code)
        except Exception:  # noqa: BLE001 - parameter not created (yet): its default value
            return self._payroll_parameter_defaults().get(code, 0)

    def _payroll_version(self):
        self.ensure_one()
        version = self.version_id if 'version_id' in self._fields and self.version_id else \
            self.employee_id._get_version(self.date_to)
        return version.sudo()

    def _payroll_absence_base(self):
        """Monthly amount the absences are deducted from: basic, or basic + allowances, as set on the employee."""
        version = self._payroll_version()
        if version.absence_deduction_base == 'gross':
            return version.gross_salary
        return version.wage

    def _payroll_day_rate(self, base='basic'):
        """Daily rate: basic salary (or the absence base of the employee) / days per month."""
        monthly = self._payroll_absence_base() if base == 'employee' else self._payroll_version().wage
        return monthly / (self._payroll_param('payroll_month_days') or 30)

    def _payroll_hour_rate(self):
        """Hourly rate: basic daily rate / hours per day."""
        return self._payroll_day_rate('basic') / (self._payroll_param('payroll_day_hours') or 8)

    def _payroll_insurable_wage(self):
        """Social insurance wage of the employee, within the minimum and maximum insurable wage."""
        version = self._payroll_version()
        field = 'l10n_eg_social_insurance_reference'
        wage = version[field] if field in version._fields else version.wage
        low, high = self._payroll_param('payroll_si_min_wage'), self._payroll_param('payroll_si_max_wage')
        if low:
            wage = max(wage, low)
        if high:
            wage = min(wage, high)
        return wage

    def _payroll_overtime_codes(self):
        return set(self.env['hr.comp.payslip.item'].sudo().search([('is_overtime', '=', True)]).mapped('code'))

    # ---------------------------------------------------------------- inputs
    def _payroll_same_period_slips(self):
        """Other payslips of the employee overlapping this payslip period, cancelled ones excluded."""
        self.ensure_one()
        return self.search([
            ('id', '!=', self.id), ('employee_id', '=', self.employee_id.id), ('state', '!=', 'cancel'),
            ('date_from', '<=', self.date_to), ('date_to', '>=', self.date_from),
        ])

    def _payroll_overtime_slips(self):
        """Separate overtime payslips of the period: the salary payslip does not pay the overtime then."""
        return self._payroll_same_period_slips().filtered(lambda s: s.payroll_mode == 'overtime')

    def _payroll_pays(self, item):
        """Whether this payslip pays the payslip item."""
        self.ensure_one()
        if self.payroll_mode == 'overtime':
            return item.is_overtime
        if item.is_overtime:
            return self.payroll_mode == 'all' and not self._payroll_overtime_slips()
        return True

    def _payroll_set_inputs(self, items, amounts):
        """Replace the inputs of the items by {item: amount} (only the items paid by this payslip)."""
        self.ensure_one()
        self.input_line_ids.filtered(lambda l: l.input_type_id.code in items.mapped('code')).unlink()
        lines = [Command.create({'input_type_id': item._input_type().id, 'amount': amount})
                 for item, amount in amounts.items() if amount and self._payroll_pays(item)]
        if lines:
            self.struct_id._payroll_ensure_items(items.filtered(lambda i: i in amounts))
            self.write({'input_line_ids': lines})

    def _payroll_adjustments(self):
        """Manual amounts of the employee in the months overlapping the payslip."""
        self.ensure_one()
        return self.env['hr.comp.adjustment'].sudo().search([
            ('employee_id', '=', self.employee_id.id),
            ('sheet_id.date_from', '<=', self.date_to), ('sheet_id.date_to', '>=', self.date_from),
        ])

    def _payroll_sync_manual_inputs(self):
        items = self.env['hr.comp.payslip.item'].sudo().with_context(active_test=False).search([('source', '=', 'manual')])
        for slip in self.filtered(lambda s: s.state in EDITABLE_STATES):
            lines = slip._payroll_adjustments().filtered(lambda l: slip._payroll_pays(l.item_id))
            lines.filtered(lambda l: not l.locked).payslip_id = slip
            amounts = defaultdict(float)
            for line in lines.filtered(lambda l: l.item_id.active):
                amounts[line.item_id] += line.value
            slip._payroll_set_inputs(items, amounts)

    def _comp_sync_inputs(self):
        fixed_type = self.env.ref('hr_compensation_payroll.input_comp_fixed', raise_if_not_found=False)
        for slip in self.filtered(lambda s: s.state in EDITABLE_STATES):
            slip.input_line_ids.filtered(
                lambda l: l.input_type_id.code == FIXED_CODE or (l.input_type_id.code or '').startswith(ALLOWANCE_PREFIX)
            ).unlink()
            if slip.payroll_mode == 'overtime':
                continue  # separate overtime payslip: the allowances are paid with the salary
            version = slip._payroll_version()
            lines = []
            if version.fixed_allowance and fixed_type:
                lines.append((0, 0, {'input_type_id': fixed_type.id, 'amount': version.fixed_allowance}))
            for allowance, amount in version._effective_allowances():
                lines.append((0, 0, {'input_type_id': allowance._payroll_input_type().id, 'amount': amount}))
            slip.write({'input_line_ids': lines})

    def _payroll_sync_inputs(self):
        """Fill the inputs of the payslips before computing them (extended by the attendance module)."""
        self._comp_sync_inputs()
        self._payroll_sync_manual_inputs()

    def compute_sheet(self):
        self.filtered(lambda s: s.payroll_mode == 'overtime')._payroll_check_overtime_paid_once(paid_here=True)
        self._payroll_sync_inputs()
        res = super().compute_sheet()
        # an overtime payslip takes the overtime off the salary payslips not validated yet
        salary_slips = self.browse()
        for slip in self.filtered(lambda s: s.payroll_mode == 'overtime'):
            salary_slips |= slip._payroll_same_period_slips().filtered(
                lambda s: s.state in EDITABLE_STATES and s.payroll_mode != 'overtime')
        salary_slips.filtered(lambda s: s.payroll_mode == 'all').payroll_mode = 'salary'
        codes = self._payroll_overtime_codes()
        salary_slips = (salary_slips - self).filtered(lambda s: set(s.input_line_ids.mapped('input_type_id.code')) & codes)
        if salary_slips:
            salary_slips.compute_sheet()
        return res

    def action_payslip_done(self):
        self._payroll_check_overtime_paid_once()
        return super().action_payslip_done()

    def action_register_payment(self):
        """Pay: with two nets in the structure (salary, overtime), Payroll looks for a single NET rule.
        The net of this payslip is the one computed on it, paid in its own accrued account."""
        nets = self.struct_id.rule_ids.filtered(lambda r: r.code == 'NET')
        if len(nets) <= 1:
            return super().action_register_payment()
        self.ensure_one()
        net = self.line_ids.filtered(lambda l: l.code == 'NET').salary_rule_id
        if not net or not net.account_credit.reconcile:
            raise UserError(self.env._(
                'The credit account of the net rule %(rule)s must allow reconciliation (Accounting > Chart of '
                'Accounts > %(account)s > Allow Reconciliation).',
                rule=net.name or 'NET', account=net.account_credit.display_name or '-'))
        if self.move_id.filtered(lambda m: m.state != 'posted') or not self.move_id:
            raise UserError(self.env._('You can only register payment for posted journal entries.'))
        return self.move_id.line_ids.action_register_payment(
            ctx={'default_partner_id': self.employee_id.work_contact_id.id,
                 'default_partner_bank_id': self.employee_id.primary_bank_account_id.id,
                 'default_company_id': self.company_id.id})

    def _payroll_check_overtime_paid_once(self, paid_here=False):
        """The overtime of a period is never paid by two validated payslips."""
        codes = self._payroll_overtime_codes()
        for slip in self:
            if not (paid_here or any(l.total for l in slip.line_ids if l.code in codes)):
                continue
            for other in slip._payroll_same_period_slips().filtered(lambda s: s.state not in EDITABLE_STATES):
                if any(l.total for l in other.line_ids if l.code in codes):
                    raise UserError(self.env._(
                        'The overtime of %(employee)s is already paid with the payslip %(payslip)s.',
                        employee=slip.employee_id.name, payslip=other.name))

    # ---------------------------------------------------------------- the three compute buttons
    def _payroll_salary_slips(self):
        """The salary payslips of the selection (overtime payslips left out), all of them still editable."""
        slips = self.filtered(lambda s: s.payroll_mode != 'overtime')
        if slips.filtered(lambda s: s.state not in EDITABLE_STATES):
            raise UserError(self.env._('Only payslips that are not validated yet can be computed again.'))
        return slips

    def action_payroll_compute_all(self):
        """Salary plus the overtime minus the deductions, on one payslip: the draft overtime payslips of the
        period are deleted (a validated one keeps the overtime off the salary payslip: never paid twice)."""
        slips = self._payroll_salary_slips()
        overtime_slips = self.browse()
        for slip in slips:
            overtime_slips |= slip._payroll_overtime_slips()
        paid = overtime_slips.filtered(lambda s: s.state not in EDITABLE_STATES)
        if paid:
            raise UserError(self.env._(
                'The overtime of %(employee)s is already paid with the payslip %(payslip)s.',
                employee=paid[0].employee_id.name, payslip=paid[0].name))
        overtime_slips.payroll_adjustment_ids.payslip_id = False
        overtime_slips.unlink()
        slips.payroll_mode = 'all'
        slips.compute_sheet()

    def action_payroll_compute_salary(self):
        """Salary minus the deductions, without the overtime."""
        slips = self._payroll_salary_slips()
        slips.payroll_mode = 'salary'
        slips.compute_sheet()

    def _payroll_has_overtime(self):
        """Whether the employee has overtime to pay in the period (extended by the attendance module)."""
        self.ensure_one()
        overtime_items = self.env['hr.comp.payslip.item'].sudo().search([('is_overtime', '=', True)])
        return any(l.value for l in self._payroll_adjustments()
                   if l.item_id in overtime_items)

    def action_payroll_compute_overtime(self):
        """Pay the overtime on separate payslips (same structure), in a batch of their own: the salary
        payslips are computed again without the overtime (salary minus the deductions)."""
        salary_slips = self._payroll_salary_slips()
        Run = self.env['hr.payslip.run']
        overtime_slips = self.browse()
        runs = {}
        for slip in salary_slips:
            existing = slip._payroll_overtime_slips()
            if existing:
                overtime_slips |= existing
                continue
            if not slip._payroll_has_overtime():
                continue
            run = slip.payslip_run_id
            if run and run not in runs:
                vals = {'name': self.env._('%s - Overtime', run.name)}
                for fname in ('company_id', 'date_start', 'date_end'):
                    if fname in run._fields and run[fname]:
                        vals[fname] = run[fname].id if fname == 'company_id' else run[fname]
                runs[run] = Run.create(vals)
            vals = {
                'name': self.env._('Overtime - %s', slip.employee_id.name),
                'employee_id': slip.employee_id.id,
                'date_from': slip.date_from,
                'date_to': slip.date_to,
                'struct_id': slip.struct_id.id,
                'payroll_mode': 'overtime',
                'payslip_run_id': runs[run].id if run else False,
            }
            for fname in ('company_id', 'version_id'):
                if fname in slip._fields and slip[fname]:
                    vals[fname] = slip[fname].id
            overtime_slips |= self.create(vals)
        if not overtime_slips:
            raise UserError(self.env._('No overtime to pay for these payslips.'))
        overtime_slips.filtered(lambda s: s.state in EDITABLE_STATES).compute_sheet()
        salary_slips.payroll_mode = 'salary'
        salary_slips.compute_sheet()
        return {
            'type': 'ir.actions.act_window', 'name': self.env._('Overtime Payslips'), 'res_model': 'hr.payslip',
            'view_mode': 'list,form', 'domain': [('id', 'in', overtime_slips.ids)],
        }

    # ---------------------------------------------------------------- install
    @api.model
    def _payroll_install_parameters(self, module, parameters):
        """Create the rule parameters (once: the values changed by the user are kept)."""
        if 'hr.rule.parameter' not in self.env:
            return
        Parameter = self.env['hr.rule.parameter'].sudo()
        for code, (name, value) in parameters.items():
            if Parameter.search_count([('code', '=', code)]):
                continue
            try:
                with self.env.cr.savepoint():
                    Parameter._load_records([{
                        'xml_id': f'{module}.rule_parameter_{code}',
                        'values': {'name': name, 'code': code, 'parameter_version_ids': [Command.create({
                            'date_from': '2020-01-01', 'parameter_value': repr(value)})]},
                        'noupdate': True,
                    }])
            except Exception:  # noqa: BLE001 - the rules then use the default value
                _logger.warning('Rule parameter %s not created', code, exc_info=True)

    @api.model
    def _payroll_install(self):
        """Parameters, buttons, payslip tab and menus. The forms and menus of Payroll are only extended when
        they exist in this version of Payroll: a missing one is skipped instead of failing the install."""
        self._payroll_install_parameters('hr_compensation_payroll', PARAMETERS)
        # buttons of the previous version of the attendance module (they read a field removed since)
        for old in ('hik_attendance_payroll.hr_payslip_view_form_hik_compute',
                    'hik_attendance_payroll.hr_payslip_run_view_form_hik_compute'):
            view = self.env.ref(old, raise_if_not_found=False)
            if view:
                view.sudo().unlink()
        buttons = """
            <button name="action_payroll_compute_salary" type="object" string="Compute Salary"
                    help="Salary minus the deductions, without the overtime"{cond}/>
            <button name="action_payroll_compute_overtime" type="object" string="Compute Overtime"
                    help="The overtime only, on its own payslip in a separate batch"{cond}/>
            <button name="action_payroll_compute_all" type="object" string="Compute Salary + Overtime"
                    help="Salary plus the overtime minus the deductions, on one payslip"{cond}/>"""
        slip_cond = ' invisible="state not in (\'draft\', \'verify\') or payroll_mode == \'overtime\'"'
        adjustments = """
            <page string="Manual Amounts" name="payroll_adjustments">
                <field name="payroll_adjustment_ids" readonly="state not in ('draft', 'verify')"
                       context="{'default_payslip_id': id}">
                    <list editable="bottom">
                        <field name="date"/>
                        <field name="item_id" options="{'no_create': True}"/>
                        <field name="unit"/>
                        <field name="value"/>
                        <field name="note"/>
                        <field name="sheet_state"/>
                    </list>
                </field>
                <div class="text-muted">
                    The same lines as in Payroll &gt; Manual Amounts: taken by every compute of the payslip.
                </div>
            </page>"""
        self._payroll_extend_view('hr_payroll.view_hr_payslip_form', 'hr.payslip', 'hr_payslip_view_form_payroll',
                                  '<xpath expr="//header" position="inside"><field name="payroll_mode" invisible="1"/>'
                                  + buttons.format(cond=slip_cond) + '</xpath>')
        self._payroll_extend_view('hr_payroll.view_hr_payslip_form', 'hr.payslip', 'hr_payslip_view_form_payroll_tab',
                                  f'<xpath expr="//notebook" position="inside">{adjustments}</xpath>')
        self._payroll_extend_view('hr_payroll.hr_payslip_run_form', 'hr.payslip.run', 'hr_payslip_run_view_form_payroll',
                                  '<xpath expr="//header" position="inside">' + buttons.format(cond='') + """
            <button name="action_payroll_adjustments" type="object" string="Manual Amounts"/></xpath>""")
        self._payroll_create_menus()

    @api.model
    def _payroll_extend_view(self, parent_xmlid, model, xmlid, arch, module='hr_compensation_payroll'):
        parent = self.env.ref(parent_xmlid, raise_if_not_found=False)
        if not parent:
            return
        try:
            with self.env.cr.savepoint():
                self.env['ir.ui.view'].sudo()._load_records([{
                    'xml_id': f'{module}.{xmlid}',
                    'values': {'name': f'{model}.form.payroll.{xmlid}', 'model': model, 'inherit_id': parent.id,
                               'arch': arch},
                    'noupdate': False,
                }])
        except Exception:  # noqa: BLE001 - a form without header or notebook: the actions stay in the Action menu
            _logger.warning('View %s not extended', parent_xmlid, exc_info=True)

    @api.model
    def _payroll_create_menus(self):
        """Manual Amounts in the Payroll menu, Payslip Items in its configuration (Employees > Compensation
        when the Payroll menus are not found)."""
        root = self.env.ref('hr_payroll.menu_hr_payroll_root', raise_if_not_found=False)
        config = self.env.ref('hr_payroll.menu_hr_payroll_configuration', raise_if_not_found=False)
        fallback = self.env.ref('hr_compensation.menu_hr_compensation')
        menus = [
            ('menu_payroll_adjustments', 'Manual Amounts', root or fallback, 'action_payroll_adjustment_sheet', 25),
            ('menu_payroll_items', 'Payslip Items', config or fallback, 'action_payroll_item', 5),
        ]
        for xmlid, name, parent, action, sequence in menus:
            self.env['ir.ui.menu'].sudo()._load_records([{
                'xml_id': f'hr_compensation_payroll.{xmlid}',
                'values': {'name': name, 'parent_id': parent.id, 'sequence': sequence,
                           'action': f'ir.actions.act_window,{self.env.ref(f"hr_compensation_payroll.{action}").id}'},
                'noupdate': False,
            }])


class HrPayslipRun(models.Model):
    _inherit = 'hr.payslip.run'

    def action_payroll_compute_salary(self):
        return self.slip_ids.action_payroll_compute_salary()

    def action_payroll_compute_overtime(self):
        return self.slip_ids.action_payroll_compute_overtime()

    def action_payroll_compute_all(self):
        return self.slip_ids.action_payroll_compute_all()

    def action_payroll_adjustments(self):
        """Manual amounts of the month of the batch."""
        self.ensure_one()
        day = self.slip_ids[:1].date_to or (self.date_end if 'date_end' in self._fields else False) or \
            fields.Date.context_today(self)
        sheet = self.env['hr.comp.adjustment.sheet']._for_date(self.company_id or self.env.company, day)
        return {'type': 'ir.actions.act_window', 'res_model': 'hr.comp.adjustment.sheet', 'res_id': sheet.id,
                'view_mode': 'form'}


class HrPayrollStructure(models.Model):
    _inherit = 'hr.payroll.structure'

    # Egyptian structure rules paying an allowance from a contract field (l10n_eg_*): when that field does not
    # exist in the database, the rule is linked to the matching allowance type instead.
    BROKEN_RULE_ALLOWANCES = {
        'MEAL': 'allowance_meals',
        'TA': 'allowance_transport',
        'HOU': 'allowance_housing',
        'FIXED': 'allowance_fixed_incentive',
    }

    def _comp_link_broken_rules(self):
        """Link the broken allowance rules of the structure (they read a missing contract field) to our
        allowance types, so they read the Compensation tab instead of failing."""
        broken = self._comp_rules_with_missing_fields()
        for rule in broken:
            xmlid = self.BROKEN_RULE_ALLOWANCES.get(rule.code)
            allowance = xmlid and self.env.ref(f'hr_compensation.{xmlid}', raise_if_not_found=False)
            if allowance and not allowance.payroll_rule_code:
                allowance.with_context(active_test=False).payroll_rule_code = rule.code

    def action_comp_add_rules(self):
        """One salary rule per allowance, so every allowance is paid once, and only when the employee has it.

        An allowance type with a Salary Rule Code takes over the existing rule of that code
        (e.g. MEAL of the Egyptian structure): the rule keeps its category, so the social insurance
        and tax rules keep working, but its amount now comes from the Compensation tab.
        Other allowances get a new rule. Run it again after adding allowance types."""
        Rule = self.env['hr.salary.rule']
        category = self.env.ref('hr_payroll.ALW')
        for structure in self:
            structure._comp_link_broken_rules()
            allowances = [(FIXED_CODE, FIXED_CODE, self.env._('Fixed Allowance'))] + [
                (t._payroll_code(), t.payroll_rule_code or t._payroll_code(), t.name)
                for t in self.env['hr.allowance.type'].search([])]
            rules_by_code = {rule.code: rule for rule in structure.rule_ids}
            # just before the taxable salary (GROSS) when there is one: the allowances are part of it
            gross = rules_by_code.get('GROSS')
            sequence = gross.sequence - 1 if gross and gross.sequence > 1 else DEFAULT_SEQUENCE
            for input_code, rule_code, label in allowances:
                if rule_code in rules_by_code:
                    rule = rules_by_code[rule_code]
                    rule._comp_take_over(input_code)
                    # a rule created by an earlier run for the same allowance would pay it twice
                    (structure.rule_ids - rule).filtered(lambda r: r.comp_input_code == input_code).write(
                        {'active': False})
                    if rule.comp_input_code and rule.sequence >= DEFAULT_SEQUENCE > sequence:
                        rule.sequence = sequence  # added after GROSS by an earlier version
                    continue
                Rule.create({
                    'name': label,
                    'code': rule_code,
                    'sequence': sequence,
                    'struct_id': structure.id,
                    'category_id': category.id,
                    'condition_select': 'python',
                    'condition_python': f"result = '{input_code}' in inputs",
                    'amount_select': 'code',
                    'amount_python_compute': f"result = inputs['{input_code}'].amount",
                    'appears_on_payslip': True,
                    'comp_input_code': input_code,
                })
        return {'type': 'ir.actions.client', 'tag': 'display_notification',
                'params': {'message': self.env._('Allowance rules added to the structure.'), 'type': 'success'}}

    # ---------------------------------------------------------------- payslip items
    def _payroll_item_sequence(self, taxable):
        """Taxable: just before the taxable salary (GROSS). Otherwise just before the net salary."""
        self.ensure_one()
        rules = {rule.code: rule for rule in self.rule_ids}
        anchor = rules.get('GROSS') if taxable else rules.get('NET')
        return anchor.sequence - 1 if anchor and anchor.sequence > 1 else DEFAULT_SEQUENCE + 30

    def _payroll_ensure_items(self, items):
        """Payslip items paid by a payslip of these structures must have their rule there."""
        for structure in self:
            missing = items.filtered(lambda i: structure not in i.structure_ids)
            if missing:
                missing.sudo().write({'structure_ids': [Command.link(structure.id)]})

    def action_payroll_prepare(self):
        """Prepare the structure in one click: allowances of the compensation tab, payslip items (loans,
        penalties, attendance...), social insurance and income tax only for the employees who have them,
        absences deducted from the base chosen on the employee. Run it again any time: nothing is duplicated."""
        self.action_comp_add_rules()
        items = self.env['hr.comp.payslip.item'].sudo().search([])
        for structure in self:
            items.write({'structure_ids': [Command.link(structure.id)]})
            structure._payroll_prepare_rules()
            structure._payroll_prepare_nets()
            structure._payroll_fill_accounts()
            structure_type = structure.type_id if 'type_id' in structure._fields else False
            if structure_type and 'default_struct_id' in structure_type._fields and \
                    structure_type.default_struct_id != structure:
                structure_type.default_struct_id = structure
        return {'type': 'ir.actions.client', 'tag': 'display_notification',
                'params': {'message': self.env._('Structure prepared: %s', ', '.join(self.mapped('name'))),
                           'type': 'success'}}

    def _payroll_prepare_rules(self):
        """Insurance, tax and absence rules of the Egyptian structures (by code; the original code is kept on the rule)."""
        self.ensure_one()
        rules = {rule.code: rule for rule in self.rule_ids}
        for code, (parameter, sign) in INSURANCE_RULES.items():
            if code in rules:
                rules[code]._comp_keep_original()
                rules[code].write({
                    'condition_select': 'python',
                    'condition_python': 'result = version.social_insurance',
                    'amount_select': 'code',
                    'amount_python_compute': (f"result = payslip._payroll_insurable_wage()\n"
                                              f"result_rate = {'-' if sign < 0 else ''}payslip._payroll_param('{parameter}')"),
                })
        for code in TAX_RULES:
            if code in rules:
                rules[code]._comp_keep_original()
                rules[code].write({'condition_select': 'python', 'condition_python': 'result = version.income_tax'})
        if 'TOTTB' in rules and 'TAXBLEAM' in rules and rules['TOTTB'].sequence <= rules['TAXBLEAM'].sequence:
            rules['TOTTB'].sequence = rules['TAXBLEAM'].sequence + 1  # the tax needs the taxable amount first
        for code in ABSENCE_RULES:
            rule = rules.get(code)
            if rule and ABSENCE_BASE_RE.search(rule.amount_python_compute or ''):
                rule._comp_keep_original()
                rule.amount_python_compute = ABSENCE_BASE_RE.sub('payslip._payroll_absence_base()',
                                                                 rule.amount_python_compute)
        Rule = self.env['hr.salary.rule'].sudo()
        names = {'LIFE_INS': self.env._('Life Insurance'), 'MEDICAL_INS': self.env._('Medical Insurance'),
                 'STAMP_TAX': self.env._('Stamp Tax')}
        for code, (_name, flag, amount, category_code, sign) in EMPLOYEE_RULES.items():
            if code not in rules:  # created once: then the rule is the user's (category, accounts...)
                Rule.create({
                    'name': names[code], 'code': code, 'struct_id': self.id,
                    'sequence': self._payroll_item_sequence(taxable=False),
                    'category_id': self._payroll_category(category_code).id,
                    'condition_select': 'python',
                    'condition_python': f'result = version.{flag} and bool(version.{amount})',
                    'amount_select': 'code',
                    'amount_python_compute': f"result = {'-' if sign < 0 else ''}version.{amount}",
                    'appears_on_payslip': True,
                })

    def _payroll_prepare_nets(self):
        """Net Salary (salary payslips) and Net Overtime (separate overtime payslips): both with the code NET,
        so Odoo pays the right amount, each credited to its own accrued account."""
        self.ensure_one()
        nets = self.with_context(active_test=False).rule_ids.filtered(lambda r: r.code == 'NET')
        salary = nets.filtered(lambda r: r.payroll_net_for == 'salary')[:1] or \
            nets.filtered(lambda r: not r.payroll_net_for and r.active)[:1]
        if not salary:
            return
        if not salary.payroll_net_for:
            salary.payroll_net_for = 'salary'
        if not nets.filtered(lambda r: r.payroll_net_for == 'overtime'):
            vals = {'name': self.env._('Net Overtime'), 'payroll_net_for': 'overtime', 'struct_id': self.id}
            for fname in ('account_debit', 'account_credit'):
                if fname in salary._fields:
                    vals[fname] = False
            salary.sudo().copy(vals)

    def _payroll_category(self, code):
        Category = self.env['hr.salary.rule.category'].sudo()
        return self.env.ref(f'hr_payroll.{code}', raise_if_not_found=False) or \
            Category.search([('code', '=', code)], limit=1) or \
            Category.create({'name': self.env._('Company Contribution') if code == 'COMP' else code, 'code': code})

    def _payroll_fill_accounts(self):
        """Accounts of the chart of the company, only where the rule has none: the user's choices are kept."""
        self.ensure_one()
        Rule = self.env['hr.salary.rule']
        side = next((index for word, index in STRUCTURE_SIDES.items() if word in (self.name or '')), None)
        if side is None or 'account_debit' not in Rule._fields:
            return
        Account = self.env['account.account'].sudo()
        accounts = {}

        def account(code):
            if code not in accounts:
                accounts[code] = Account.search([('code', '=', code)], limit=1)
            return accounts[code]

        for rule in self.rule_ids.filtered(lambda r: r.code in ACCOUNTS or r.payroll_net_for):
            codes = (None, None) + NET_ACCOUNTS[rule.payroll_net_for] if rule.payroll_net_for else ACCOUNTS[rule.code]
            vals = {}
            if codes[side] and not rule.account_debit and account(codes[side]):
                vals['account_debit'] = account(codes[side]).id
            if codes[2 + side] and not rule.account_credit and account(codes[2 + side]):
                vals['account_credit'] = account(codes[2 + side]).id
            if 'employee_move_line' in rule._fields and not rule.employee_move_line:
                vals['employee_move_line'] = True  # the employee on the journal item
            if vals:
                rule.sudo().write(vals)

    def _payroll_move_credits_to_nets(self):
        """Once (upgrade): the accrued accounts the previous version set on the lines are now on the nets."""
        if 'account_credit' not in self.env['hr.salary.rule']._fields:
            return
        Account = self.env['account.account'].sudo()
        for structure in self:
            structure.rule_ids.filtered(
                lambda r: r.code in ACCOUNTS and r.code != 'SICOMP' and r.account_credit.code in ACCRUED_CODES
            ).sudo().write({'account_credit': False})
            # the nets as agreed (they may hold another account from before)
            side = next((index for word, index in STRUCTURE_SIDES.items() if word in (structure.name or '')), None)
            if side is None:
                continue
            for net in structure.rule_ids.filtered('payroll_net_for'):
                account = Account.search([('code', '=', NET_ACCOUNTS[net.payroll_net_for][side])], limit=1)
                if account:
                    net.sudo().write({'account_debit': False, 'account_credit': account.id})

    def _comp_rules_with_missing_fields(self):
        """Active rules of the structures reading a field that does not exist in this database
        (e.g. version.l10n_eg_meal_allowance when the module defining it is not installed)."""
        models_by_name = {'version': self.env['hr.version'], 'contract': self.env['hr.version'],
                          'employee': self.env['hr.employee']}
        broken = {}
        for rule in self.rule_ids:
            code = f'{rule.condition_python or ""}\n{rule.amount_python_compute or ""}'
            missing = sorted({f'{obj}.{name}' for obj, name in RULE_FIELD_RE.findall(code)
                              if name not in models_by_name[obj]._fields
                              and not hasattr(type(models_by_name[obj]), name)})
            if missing:
                broken[rule] = missing
        return broken

    def action_comp_archive_broken_rules(self):
        """Archive the rules that can only fail because they read fields missing from this database.

        A rule whose result is used by other rules (e.g. TAXBLEAM for the income tax) is never archived:
        it is only reported, its code has to be corrected instead."""
        broken = self._comp_rules_with_missing_fields()
        if not broken:
            raise UserError(self.env._('No rule of this structure reads a missing field.'))
        archived, kept = {}, {}
        for rule, missing in broken.items():
            others = (rule.struct_id.rule_ids - rule).filtered('active')
            used = any(re.search(rf'\b{re.escape(rule.code)}\b',
                                 f'{other.condition_python or ""}\n{other.amount_python_compute or ""}')
                       for other in others)
            (kept if used else archived)[rule] = missing
        for rule in archived:
            rule.active = False
        _ = self.env._
        lines = []
        if archived:
            lines.append(_('Archived rules: %s', ', '.join(f'{r.code} ({", ".join(f)})' for r, f in archived.items())))
        if kept:
            lines.append(_('Not archived because other rules use them, correct their code: %s',
                           ', '.join(f'{r.code} ({", ".join(f)})' for r, f in kept.items())))
        return {'type': 'ir.actions.client', 'tag': 'display_notification',
                'params': {'message': ' | '.join(lines), 'type': 'warning', 'sticky': True}}
