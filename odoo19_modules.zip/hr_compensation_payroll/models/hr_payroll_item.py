from odoo import api, fields, models
from odoo.exceptions import ValidationError

DEFAULT_SEQUENCE = 150


class HrPayrollItem(models.Model):
    """An addition or a deduction of the payslip: created here once, its salary rule is created in the chosen
    structures and kept in sync. Its accounts are those of its salary rules (one per structure), never overwritten."""
    _name = 'hr.comp.payslip.item'
    _description = 'Payslip Item'
    _order = 'sequence, id'

    name = fields.Char(required=True, translate=True)
    code = fields.Char(required=True, help='Code of the salary rule and of the payslip input, e.g. LOAN.')
    sequence = fields.Integer(default=10)
    active = fields.Boolean(default=True)
    kind = fields.Selection([('addition', 'Addition'), ('deduction', 'Deduction')],
                            string='Type', required=True, default='deduction')
    unit = fields.Selection([('amount', 'Amount'), ('days', 'Days'), ('hours', 'Hours')],
                            required=True, default='amount',
                            help='Amount: paid as entered. Days: multiplied by the daily rate. '
                                 'Hours: multiplied by the hourly rate and the multiplier.')
    day_base = fields.Selection([('basic', 'Basic Salary'), ('employee', 'As Set on the Employee')],
                                string='Daily Rate From', default='employee', required=True,
                                help='As set on the employee: basic salary, or basic salary + allowances '
                                     '("Absence Deducted From" on the employee).')
    rate_parameter = fields.Char(
        'Multiplier (Rule Parameter)',
        help='Code of the rule parameter holding the multiplier of the hours (e.g. 1.5), changed by date in '
             'Payroll > Configuration > Rule Parameters. Empty: x 1.')
    taxable = fields.Boolean(
        'Part of the Taxable Salary', default=True,
        help='Placed before the taxable salary (GROSS): an addition is taxed, a deduction lowers the tax. '
             'Untick for e.g. a loan: placed just before the net salary.')
    is_overtime = fields.Boolean(
        'Overtime', help='Paid by "Compute Overtime", left out by "Compute Salary".')
    source = fields.Selection([('manual', 'Entered by Hand'), ('attendance', 'Attendance')],
                              default='manual', required=True, readonly=True)
    structure_ids = fields.Many2many('hr.payroll.structure', string='Salary Structures',
                                     default=lambda self: self._default_structures())
    rule_count = fields.Integer('Salary Rules', compute='_compute_rule_count')
    note = fields.Text()

    _code_unique = models.Constraint('UNIQUE(code)', 'The code of the payslip item must be unique.')

    @api.model
    def _default_structures(self):
        """The structures already prepared (they have payslip items)."""
        return self.with_context(active_test=False).search([]).structure_ids

    @api.constrains('code')
    def _check_code(self):
        for item in self:
            if not item.code.replace('_', '').isalnum() or not item.code.isupper():
                raise ValidationError(self.env._('The code must be in capital letters, digits and "_" only (e.g. LOAN).'))

    def _compute_rule_count(self):
        Rule = self.env['hr.salary.rule'].sudo()
        for item in self:
            item.rule_count = Rule.search_count([('comp_input_code', '=', item.code)])

    # ---------------------------------------------------------------- salary rules
    def _input_type(self):
        self.ensure_one()
        InputType = self.env['hr.payslip.input.type'].sudo()
        units = {'amount': '', 'days': self.env._(' (days)'), 'hours': self.env._(' (hours)')}
        vals = {'name': self.name + units[self.unit]}
        if 'is_quantity' in InputType._fields:
            vals['is_quantity'] = self.unit != 'amount'  # days and hours are shown without currency
        if 'available_in_attachments' in InputType._fields:
            # entered in the Manual Amounts only: a salary adjustment with the same code would be replaced by them
            vals['available_in_attachments'] = False
        input_type = InputType.search([('code', '=', self.code)], limit=1)
        if input_type:
            changed = {key: value for key, value in vals.items() if input_type[key] != value}
            if changed:
                input_type.write(changed)
            return input_type
        return InputType.create(dict(vals, code=self.code))

    def _rule_python(self):
        """(condition, amount) python code of the salary rule: readable, the user can check the formula."""
        self.ensure_one()
        code = self.code
        sign = '-' if self.kind == 'deduction' else ''
        condition = f"result = '{code}' in inputs and bool(inputs['{code}'].amount)"
        if self.unit == 'amount':
            amount = f"result = {sign}inputs['{code}'].amount"
        elif self.unit == 'days':
            amount = (f"result_qty = inputs['{code}'].amount\n"
                      f"result = {sign}payslip._payroll_day_rate('{self.day_base}')")
        else:
            rate = f" * payslip._payroll_param('{self.rate_parameter}')" if self.rate_parameter else ''
            amount = (f"result_qty = inputs['{code}'].amount\n"
                      f"result = {sign}payslip._payroll_hour_rate(){rate}")
        return condition, amount

    def _rule_vals(self, structure):
        self.ensure_one()
        condition, amount = self._rule_python()
        category = self.env.ref('hr_payroll.ALW' if self.kind == 'addition' else 'hr_payroll.DED')
        vals = {
            'name': self.name,
            'code': self.code,
            'sequence': structure._payroll_item_sequence(self.taxable),
            'category_id': category.id,
            'condition_select': 'python',
            'condition_python': condition,
            'amount_select': 'code',
            'amount_python_compute': amount,
            'appears_on_payslip': True,
            'comp_input_code': self.code,
            'active': self.active,
        }
        if 'employee_move_line' in self.env['hr.salary.rule']._fields:
            vals['employee_move_line'] = True  # the employee on the journal item: loans followed per employee
        return vals

    def _sync_rules(self):
        """Create or update the salary rule of the items in their structures, archive it elsewhere."""
        Rule = self.env['hr.salary.rule'].sudo().with_context(active_test=False)
        for item in self:
            item._input_type()
            managed = Rule.search([('comp_input_code', '=', item.code)])
            kept = Rule
            for structure in item.structure_ids:
                rule = managed.filtered(lambda r: r.struct_id == structure)[:1] or \
                    structure.with_context(active_test=False).rule_ids.filtered(lambda r: r.code == item.code)[:1]
                vals = item._rule_vals(structure)
                if rule:
                    if rule.comp_input_code != item.code:
                        rule._comp_keep_original()
                    rule.write(vals)
                else:
                    rule = Rule.create(dict(vals, struct_id=structure.id))
                kept |= rule
            (managed - kept).write({'active': False})

    @api.model_create_multi
    def create(self, vals_list):
        items = super().create(vals_list)
        items._sync_rules()
        return items

    def write(self, vals):
        if 'code' in vals and self.filtered(lambda i: i.code != vals['code'] and i.rule_count):
            raise ValidationError(self.env._('The code cannot be changed once the item has salary rules: '
                                             'archive it and create a new one.'))
        res = super().write(vals)
        synced = {'name', 'kind', 'unit', 'day_base', 'rate_parameter', 'taxable',
                  'structure_ids', 'active'}
        if synced & set(vals):
            self._sync_rules()
        return res

    def unlink(self):
        self.write({'active': False})
        return super().unlink()

    def action_view_rules(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window', 'name': self.name, 'res_model': 'hr.salary.rule',
            'view_mode': 'list,form', 'domain': [('comp_input_code', '=', self.code)],
            'views': [(self.env.ref('hr_compensation_payroll.hr_salary_rule_view_list_accounts').id, 'list'), (False, 'form')],
            'context': {'active_test': False},
        }
