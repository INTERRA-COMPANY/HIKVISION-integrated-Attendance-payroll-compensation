from dateutil.relativedelta import relativedelta

from odoo import api, fields, models
from odoo.exceptions import UserError
from odoo.tools import format_date

EDITABLE_SLIP_STATES = ('draft', 'verify', 'cancel')


class HrPayrollAdjustmentSheet(models.Model):
    """Manual amounts of a month (loans, variable incentives, penalties...), entered at any time during the
    month. Every compute of a payslip of the month reads them (draft or confirmed month): they are never copied,
    so a change on the payslip is a change of this sheet. Confirming computes all the payslips again."""
    _name = 'hr.comp.adjustment.sheet'
    _description = 'Monthly Manual Amounts'
    _inherit = ['mail.thread']
    _order = 'date_from desc'

    name = fields.Char(compute='_compute_name', store=True)
    company_id = fields.Many2one('res.company', required=True, default=lambda self: self.env.company)
    date_from = fields.Date('Month', required=True, default=lambda self: fields.Date.context_today(self).replace(day=1))
    date_to = fields.Date('To', compute='_compute_date_to', store=True)
    state = fields.Selection([('draft', 'Draft'), ('confirmed', 'Confirmed')], default='draft', required=True,
                             tracking=True, index=True)
    line_ids = fields.One2many('hr.comp.adjustment', 'sheet_id', string='Amounts')
    line_count = fields.Integer(compute='_compute_line_count')

    _month_unique = models.Constraint('UNIQUE(company_id, date_from)', 'This month already has its manual amounts.')

    @api.depends('date_from')
    def _compute_date_to(self):
        for sheet in self:
            sheet.date_to = sheet.date_from and sheet.date_from + relativedelta(day=31)

    @api.depends('date_from')
    def _compute_name(self):
        for sheet in self:
            sheet.name = self.env._('Manual Amounts %s', format_date(self.env, sheet.date_from, date_format='MMMM y')) \
                if sheet.date_from else False

    def _compute_line_count(self):
        for sheet in self:
            sheet.line_count = len(sheet.line_ids)

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get('date_from'):
                vals['date_from'] = fields.Date.to_date(vals['date_from']).replace(day=1)
        return super().create(vals_list)

    @api.model
    def _for_date(self, company, day):
        """Sheet of the month of the day, created when missing."""
        month = day.replace(day=1)
        return self.search([('company_id', '=', company.id), ('date_from', '=', month)], limit=1) or \
            self.create({'company_id': company.id, 'date_from': month})

    def _payslips_to_recompute(self):
        return self.env['hr.payslip'].search([
            ('company_id', 'in', self.company_id.ids), ('state', 'in', ('draft', 'verify')),
            ('date_from', '<=', max(self.mapped('date_to'))), ('date_to', '>=', min(self.mapped('date_from'))),
        ])

    def action_confirm(self):
        """Confirm and send to the payslips: the payslips of the month not validated yet are computed again."""
        self.write({'state': 'confirmed'})
        self._payslips_to_recompute().compute_sheet()

    def action_draft(self):
        manager = self.env.ref('hr_payroll.group_hr_payroll_manager', raise_if_not_found=False) or \
            self.env.ref('hr.group_hr_manager')
        if not self.env.user.has_group(manager.get_external_id()[manager.id]):
            raise UserError(self.env._('Only a payroll administrator can set the manual amounts back to draft.'))
        self.write({'state': 'draft'})

    def action_view_summary(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window', 'name': self.name, 'res_model': 'hr.comp.adjustment',
            'view_mode': 'pivot,list', 'domain': [('sheet_id', '=', self.id)],
            'context': {'default_sheet_id': self.id},
        }


class HrPayrollAdjustment(models.Model):
    _name = 'hr.comp.adjustment'
    _description = 'Manual Amount'
    _order = 'date, id'

    sheet_id = fields.Many2one('hr.comp.adjustment.sheet', string='Month', required=True, ondelete='cascade',
                               index=True)
    sheet_state = fields.Selection(related='sheet_id.state', string='Status')
    company_id = fields.Many2one(related='sheet_id.company_id', store=True)
    date = fields.Date(required=True, default=fields.Date.context_today)
    employee_id = fields.Many2one('hr.employee', string='Employee', required=True, index=True)
    item_id = fields.Many2one('hr.comp.payslip.item', string='Item', required=True, ondelete='restrict',
                              domain=[('source', '=', 'manual')])
    kind = fields.Selection(related='item_id.kind')
    unit = fields.Selection(related='item_id.unit')
    value = fields.Float('Amount / Days / Hours', required=True)
    note = fields.Char('Reason')
    payslip_id = fields.Many2one('hr.payslip', string='Payslip', readonly=True, ondelete='set null', index=True)
    locked = fields.Boolean(compute='_compute_locked')

    @api.depends('payslip_id.state')
    def _compute_locked(self):
        for line in self:
            line.locked = bool(line.payslip_id) and line.payslip_id.state not in EDITABLE_SLIP_STATES

    def _check_editable(self):
        """A payslip already validated keeps what it paid: set it back to draft first."""
        for line in self:
            slips = self.env['hr.payslip'].search([
                ('employee_id', '=', line.employee_id.id), ('state', 'not in', EDITABLE_SLIP_STATES),
                ('date_from', '<=', line.sheet_id.date_to), ('date_to', '>=', line.sheet_id.date_from),
            ]).filtered(lambda s: (s.payroll_mode == 'overtime') == line.item_id.is_overtime)
            if slips:
                raise UserError(self.env._(
                    'The payslip %(payslip)s of %(employee)s is validated: set it back to draft to change its amounts.',
                    payslip=slips[0].name, employee=line.employee_id.name))

    def _log(self, message):
        for sheet in self.sheet_id:
            lines = self.filtered(lambda l: l.sheet_id == sheet)
            sheet.message_post(body=message + ' ' + ', '.join(
                f'{l.employee_id.name} - {l.item_id.name}: {l.value:g}' + (f' ({l.note})' if l.note else '')
                for l in lines))

    @api.model_create_multi
    def create(self, vals_list):
        Sheet = self.env['hr.comp.adjustment.sheet']
        for vals in vals_list:
            slip = self.env['hr.payslip'].browse(vals.get('payslip_id'))
            if slip:  # added from the payslip
                vals.setdefault('employee_id', slip.employee_id.id)
                vals.setdefault('date', min(fields.Date.context_today(self), slip.date_to))
                if not vals.get('sheet_id'):
                    vals['sheet_id'] = Sheet._for_date(slip.company_id, slip.date_to).id
            elif not vals.get('sheet_id'):
                day = fields.Date.to_date(vals.get('date')) or fields.Date.context_today(self)
                vals['sheet_id'] = Sheet._for_date(self.env.company, day).id
        lines = super().create(vals_list)
        lines._check_editable()
        lines._log(self.env._('Added:'))
        return lines

    def write(self, vals):
        if set(vals) == {'payslip_id'}:  # linked by the payslip computation
            return super().write(vals)
        self._check_editable()
        res = super().write(vals)
        self._check_editable()
        self._log(self.env._('Changed:'))
        return res

    def unlink(self):
        self._check_editable()
        self._log(self.env._('Removed:'))
        return super().unlink()
