{
    'name': 'Employee Compensation - Payroll Bridge',
    'version': '19.0.1.6.0',
    'category': 'Human Resources/Payroll',
    'summary': 'Allowances, payslip items with their accounts, monthly manual amounts, insurance and tax per employee, '
               'compute salary / overtime / both',
    'author': 'Custom',
    'license': 'OEEL-1',
    'depends': ['hr_compensation', 'hr_payroll', 'hr_payroll_account'],
    'data': [
        'security/ir.model.access.csv',
        'data/hr_payslip_input_type_data.xml',
        'data/hr_payroll_item_data.xml',
        'views/hr_allowance_type_views.xml',
        'views/hr_payroll_structure_views.xml',
        'views/hr_payroll_item_views.xml',
        'views/hr_payroll_adjustment_views.xml',
        'views/hr_payslip_views.xml',
        'data/hr_payroll_install.xml',
    ],
    'installable': True,
    'auto_install': True,
}
