from odoo import SUPERUSER_ID, api


def migrate(cr, version):
    """Once: the employee on every journal item of the payslip items and of the Yard / Office rules."""
    env = api.Environment(cr, SUPERUSER_ID, {})
    env['hr.comp.payslip.item'].with_context(active_test=False).search([])._sync_rules()
    for structure in env['hr.payroll.structure'].search([
            '|', ('name', 'ilike', 'Yard'), ('name', 'ilike', 'Office'), ('name', 'not ilike', 'Default')]):
        structure._payroll_fill_accounts()
