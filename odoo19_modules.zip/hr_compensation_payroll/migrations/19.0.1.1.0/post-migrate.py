def migrate(cr, version):
    """Allowances are linked to existing salary rules only when the user chooses it: drop the codes
    the previous version set by default (TA, MEAL, HOU, FIXED, VAR) on the untouched allowance types."""
    cr.execute("""
        UPDATE hr_allowance_type t
           SET payroll_rule_code = NULL
          FROM ir_model_data d
         WHERE d.model = 'hr.allowance.type' AND d.res_id = t.id AND d.module = 'hr_compensation'
           AND (d.name, t.payroll_rule_code) IN (('allowance_transport', 'TA'), ('allowance_meals', 'MEAL'),
                ('allowance_housing', 'HOU'), ('allowance_fixed_incentive', 'FIXED'),
                ('allowance_variable_incentive', 'VAR'))
    """)
