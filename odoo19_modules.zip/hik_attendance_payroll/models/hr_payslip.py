from odoo import api, fields, models
from odoo.exceptions import UserError

# payslip item code -> days or hours of the attendance sheet
SHEET_VALUES = {
    'HIK_LATE': lambda sheet: sheet.late_days + sheet.early_days,
    'HIK_ABSENCE': lambda sheet: sheet.absence_days,
    'HIK_OT_WORKDAY': lambda sheet: sheet.ot_workday_minutes / 60.0,
    'HIK_OT_HOLIDAY': lambda sheet: sheet.ot_holiday_minutes / 60.0,
    'HIK_OT_WEEKLY': lambda sheet: sheet.ot_weekly_off_minutes / 60.0,
}
OVERTIME_TYPES = {'workday': 'HIK_OT_WORKDAY', 'holiday': 'HIK_OT_HOLIDAY', 'weekly_off': 'HIK_OT_WEEKLY'}
PARAMETERS = {
    'hik_ot_workday_rate': ('Overtime Multiplier - Working Day', 1.5),
    'hik_ot_holiday_rate': ('Overtime Multiplier - Public Holiday', 1.5),
    'hik_ot_weekly_off_rate': ('Overtime Multiplier - Weekly Day Off', 2.0),
}
# rules replaced by the attendance items: the overtime entered by hand in hours, the previous early leave input
LEGACY_RULES = ('OVTWD', 'OVTWEND', 'OVTPUB', 'HIK_EARLY')


class HikAttendanceSheet(models.Model):
    _inherit = 'hik.attendance.sheet'

    payslip_id = fields.Many2one('hr.payslip', string='Payslip', readonly=True, copy=False)


class HrPayslip(models.Model):
    _inherit = 'hr.payslip'

    hik_sheet_id = fields.Many2one('hik.attendance.sheet', string='Attendance Sheet', readonly=True, copy=False)
    hik_line_ids = fields.One2many(related='hik_sheet_id.line_ids', string='Attendance Days')

    @api.model
    def _payroll_parameter_defaults(self):
        res = super()._payroll_parameter_defaults()
        res.update({code: value for code, (_name, value) in PARAMETERS.items()})
        return res

    @api.model
    def _hik_install(self):
        """Overtime multipliers, the Attendance tab of the payslip and the attendance menus in Payroll."""
        self._payroll_install_parameters('hik_attendance_payroll', PARAMETERS)
        self._payroll_extend_view('hr_payroll.view_hr_payslip_form', 'hr.payslip', 'hr_payslip_view_form_hik_tab', """
            <xpath expr="//notebook" position="inside">
                <page string="Attendance" name="hik_attendance">
                    <group>
                        <group>
                            <field name="hik_sheet_id"/>
                            <div colspan="2">
                                <button name="{deductions}" type="action"
                                        string="Print Deductions with Amounts" class="btn-secondary me-2" icon="fa-print"/>
                                <button name="{overtime}" type="action"
                                        string="Print Overtime with Amounts" class="btn-secondary" icon="fa-print"/>
                            </div>
                        </group>
                        <group><div class="text-muted" colspan="2">
                            Days and hours of the attendance sheet: their amounts are in Salary Computation.
                        </div></group>
                    </group>
                    <field name="hik_line_ids" readonly="1">
                        <list decoration-danger="is_absent" decoration-warning="missing_punch">
                            <field name="date"/>
                            <field name="weekday"/>
                            <field name="day_type"/>
                            <field name="check_in"/>
                            <field name="check_out"/>
                            <field name="late_minutes" sum="1"/>
                            <field name="early_minutes" sum="1"/>
                            <field name="deduction_days" sum="1"/>
                            <field name="ot_type"/>
                            <field name="ot_minutes" sum="1"/>
                            <field name="ot_pending" optional="hide"/>
                            <field name="auto_note"/>
                            <field name="is_absent" column_invisible="1"/>
                            <field name="missing_punch" column_invisible="1"/>
                        </list>
                    </field>
                </page>
            </xpath>""".replace('{deductions}', str(self.env.ref('hik_attendance_payroll.action_report_payslip_hik_deductions').id))
               .replace('{overtime}', str(self.env.ref('hik_attendance_payroll.action_report_payslip_hik_overtime').id)),
            module='hik_attendance_payroll')
        root = self.env.ref('hr_payroll.menu_hr_payroll_root', raise_if_not_found=False) or \
            self.env.ref('hik_attendance.menu_hik_root', raise_if_not_found=False)
        if not root:
            return
        for xmlid, name, action, sequence in [
                ('menu_payroll_hik_sheets', 'Attendance Sheets', 'hik_attendance.action_hik_sheet', 26),
                ('menu_payroll_hik_days', 'Daily Attendance Analysis', 'hik_attendance.action_hik_sheet_line', 27)]:
            self.env['ir.ui.menu'].sudo()._load_records([{
                'xml_id': f'hik_attendance_payroll.{xmlid}',
                'values': {'name': name, 'parent_id': root.id, 'sequence': sequence,
                           'action': f'ir.actions.act_window,{self.env.ref(action).id}'},
                'noupdate': False,
            }])

    # ---------------------------------------------------------------- attendance sheet
    def _hik_sheet(self):
        self.ensure_one()
        return self.hik_sheet_id or self._hik_find_sheet()

    def _hik_find_sheet(self):
        self.ensure_one()
        return self.env['hik.attendance.sheet'].search([
            ('employee_id', '=', self.employee_id.id),
            ('date_from', '<=', self.date_to), ('date_to', '>=', self.date_from),
        ], order='date_to desc', limit=1)

    def _hik_prepare_sheet(self):
        """Attendance sheet paid by this payslip, straight from the punches: created for the payslip period
        when missing, computed again while it is a draft (a confirmed sheet is paid as reviewed)."""
        self.ensure_one()
        sheet = self.sudo()._hik_find_sheet()
        employee = self.employee_id.sudo()
        if not sheet and employee.hik_policy_id:
            sheet = sheet.create({
                'employee_id': employee.id, 'policy_id': employee.hik_policy_id.id,
                'company_id': self.company_id.id or employee.company_id.id,
                'date_from': self.date_from, 'date_to': self.date_to,
            })
        if sheet.state == 'draft':
            sheet._compute_lines()
        return sheet

    def action_hik_open_sheet(self):
        sheets = self.env['hik.attendance.sheet']
        for slip in self:
            sheets |= slip._hik_sheet()
        if not sheets:
            raise UserError(self.env._('No attendance sheet for the period of this payslip: compute the payslip first.'))
        return {
            'type': 'ir.actions.act_window', 'name': self.env._('Attendance Sheets'), 'res_model': 'hik.attendance.sheet',
            'view_mode': 'list,form', 'domain': [('id', 'in', sheets.ids)],
        }

    # ---------------------------------------------------------------- inputs: days and hours only
    def _hik_items(self):
        return self.env['hr.comp.payslip.item'].sudo().with_context(active_test=False).search([('code', 'in', list(SHEET_VALUES))])

    def _payroll_sync_inputs(self):
        super()._payroll_sync_inputs()
        items = self._hik_items()
        for slip in self.filtered(lambda s: s.state in ('draft', 'verify')):
            sheet = slip._hik_prepare_sheet()
            slip.hik_sheet_id = sheet
            if sheet and slip.payroll_mode != 'overtime':
                sheet.payslip_id = slip
            amounts = {item: round(SHEET_VALUES[item.code](sheet), 4)
                       for item in items if sheet and item.active}
            slip._payroll_set_inputs(items, amounts)

    def _payroll_has_overtime(self):
        if super()._payroll_has_overtime():
            return True
        sheet = self._hik_prepare_sheet()
        return bool(sheet and sheet.ot_total_minutes)

    def action_payslip_done(self):
        res = super().action_payslip_done()
        # the attendance paid is kept as it was paid
        self.hik_sheet_id.filtered(lambda s: s.state == 'draft').sudo().write({'state': 'confirmed'})
        return res

    # ---------------------------------------------------------------- reports
    def _hik_report_money(self):
        """Amounts of the attendance reports printed from the payslip: the rates of the salary rules and the
        totals of the payslip lines (with the separate overtime payslip of the period, if any). An amount the
        payslips do not pay yet (not computed, or computed without the overtime) is computed from the sheet
        with the same rates, so the report can be shown to the employee before the payslip is final."""
        self.ensure_one()
        slips = self | self._payroll_same_period_slips()
        totals = {}
        for line in slips.line_ids:
            totals[line.code] = totals.get(line.code, 0.0) + line.total
        sheet = self._hik_sheet()
        currency = self.company_id.currency_id
        day_basic, day_absence = self._payroll_day_rate('basic'), self._payroll_day_rate('employee')
        hour = self._payroll_hour_rate()
        rates = {ot_type: self._payroll_param(parameter) for ot_type, parameter in zip(OVERTIME_TYPES, PARAMETERS)}

        def amount(code, estimate):
            return abs(totals[code]) if code in totals else currency.round(estimate)

        late = amount('HIK_LATE', (sheet.late_days + sheet.early_days) * day_basic)
        absence = amount('HIK_ABSENCE', sheet.absence_days * day_absence)
        overtime = {ot_type: amount(code, sheet[f'ot_{ot_type}_minutes'] / 60.0 * hour * rates[ot_type])
                    for ot_type, code in OVERTIME_TYPES.items()}
        return {
            'payslip': self.name,
            'currency': currency,
            'day_basic': day_basic,
            'day_absence': day_absence,
            'hour': hour,
            'rates': rates,
            'late': late,
            'absence': absence,
            'deduction': late + absence,
            'ot': overtime,
            'ot_total': sum(overtime.values()),
        }


class HrPayslipRun(models.Model):
    _inherit = 'hr.payslip.run'

    def _hik_slips_by_sheet(self):
        """{sheet: salary payslip} of the batch."""
        result = {}
        for slip in self.slip_ids.filtered(lambda s: s.payroll_mode != 'overtime'):
            sheet = slip._hik_sheet()
            if sheet:
                result[sheet] = slip
        return result

    def _hik_sheets(self):
        return self.env['hik.attendance.sheet'].browse([sheet.id for sheet in self._hik_slips_by_sheet()])

    def _hik_report_moneys(self):
        return {sheet.id: slip._hik_report_money() for sheet, slip in self._hik_slips_by_sheet().items()}

    def action_hik_open_sheets(self):
        return self.slip_ids.action_hik_open_sheet()


class HrPayrollStructure(models.Model):
    _inherit = 'hr.payroll.structure'

    def _payroll_prepare_rules(self):
        super()._payroll_prepare_rules()
        # the overtime is now computed from the punches: the rules paying hours entered by hand would pay it twice
        self.rule_ids.filtered(lambda r: r.code in LEGACY_RULES and not r.comp_input_code).write({'active': False})
