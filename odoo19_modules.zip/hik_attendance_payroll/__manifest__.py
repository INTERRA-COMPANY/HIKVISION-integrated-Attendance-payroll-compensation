{
    'name': 'Hikvision Attendance - Payroll Bridge',
    'version': '19.0.1.5.0',
    'category': 'Human Resources/Payroll',
    'summary': 'The payslip computes the attendance sheet and pays its days and hours with salary rules',
    'author': 'Custom',
    'license': 'OEEL-1',
    'depends': ['hik_attendance', 'hr_compensation_payroll'],
    'data': [
        'data/hr_payslip_input_type_data.xml',
        'data/hr_payroll_item_data.xml',
        'views/hik_sheet_views.xml',
        'views/hr_payslip_views.xml',
        'report/hr_payslip_reports.xml',
        'data/hik_payroll_install.xml',
    ],
    'installable': True,
    'auto_install': True,
}
