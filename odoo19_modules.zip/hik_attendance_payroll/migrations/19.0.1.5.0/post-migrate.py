from odoo import SUPERUSER_ID, api

OVERTIME_NAMES = {
    'item_hik_ot_workday': ('Working Day Overtime', 'OverTime Weekdays'),
    'item_hik_ot_weekly': ('Weekly Day Off Overtime', 'Weekends Compensation'),
    'item_hik_ot_holiday': ('Public Holiday Overtime', 'Public Holiday Compensation'),
}
LEGACY_OVERTIME = ('OVTWD', 'OVTWEND', 'OVTPUB')


def migrate(cr, version):
    """Once: the names of the three overtime rules, the overtime rules entered by hand archived everywhere,
    and the Yard / Office structures prepared with their two nets (salary, overtime)."""
    env = api.Environment(cr, SUPERUSER_ID, {})
    for xmlid, (old, new) in OVERTIME_NAMES.items():
        item = env.ref(f'hik_attendance_payroll.{xmlid}', raise_if_not_found=False)
        if item and item.with_context(lang='en_US').name == old:
            item.with_context(lang='en_US').name = new
            # the same name in every language, on the item and its salary rules
            langs = {code: new for code, _name in env['res.lang'].get_installed()}
            item.update_field_translations('name', langs)
            for rule in env['hr.salary.rule'].with_context(active_test=False).search(
                    [('comp_input_code', '=', item.code)]):
                rule.update_field_translations('name', langs)
    env['hr.salary.rule'].search([('code', 'in', LEGACY_OVERTIME), ('comp_input_code', '=', False)]).active = False
    structures = env['hr.payroll.structure'].search([
        '|', ('name', 'ilike', 'Yard'), ('name', 'ilike', 'Office'), ('name', 'not ilike', 'Default')])
    if structures:
        structures.action_payroll_prepare()
        structures._payroll_move_credits_to_nets()
