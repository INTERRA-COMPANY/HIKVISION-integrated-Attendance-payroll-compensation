from dateutil.relativedelta import relativedelta

from odoo import api, fields, models
from odoo.exceptions import UserError


class HrCompensationReview(models.TransientModel):
    _name = 'hr.compensation.review'
    _description = 'Compensation Review'

    date = fields.Date('Effective Date', required=True, default=fields.Date.context_today)
    employee_ids = fields.Many2many('hr.employee', string='Employees')
    line_ids = fields.One2many('hr.compensation.review.line', 'review_id', string='Lines',
                               compute='_compute_line_ids', store=True, readonly=False)
    currency_id = fields.Many2one('res.currency', default=lambda self: self.env.company.currency_id)
    total_current = fields.Monetary('Current Basic Total', compute='_compute_totals')
    total_new = fields.Monetary('New Basic Total', compute='_compute_totals')
    total_increase = fields.Monetary('Monthly Cost of the Increase', compute='_compute_totals')

    @api.model
    def default_get(self, fields_list):
        res = super().default_get(fields_list)
        if 'employee_ids' in fields_list and not res.get('employee_ids'):
            employees = self.env['hr.employee'].search([('job_grade_id', '!=', False)])
            res['employee_ids'] = [(6, 0, employees.ids)]
        return res

    @api.depends('employee_ids')
    def _compute_line_ids(self):
        for review in self:
            existing = {line.employee_id: line for line in review.line_ids}
            commands = [(5, 0, 0)]
            for employee in review.employee_ids._origin:
                line = existing.get(employee)
                commands.append((0, 0, {
                    'employee_id': employee.id,
                    'job_grade_id': (line.job_grade_id if line else employee.job_grade_id).id,
                    'increase_pct': line.increase_pct if line else employee.annual_increase_pct,
                    'factor': line.factor if line else employee.annual_increase_factor,
                }))
            review.line_ids = commands

    @api.depends('line_ids.current_basic', 'line_ids.new_basic')
    def _compute_totals(self):
        for review in self:
            review.total_current = sum(review.line_ids.mapped('current_basic'))
            review.total_new = sum(review.line_ids.mapped('new_basic'))
            review.total_increase = review.total_new - review.total_current

    def action_apply(self):
        self.ensure_one()
        lines = self.line_ids.filtered(lambda l: l.new_basic != l.current_basic or l.is_promotion)
        if not lines:
            raise UserError(self.env._('Nothing to apply: no salary or job category changed.'))
        for line in lines:
            employee = line.employee_id
            version = employee.create_version({'date_version': self.date})
            vals = {
                'wage': line.new_basic,
                'annual_increase_pct': line.increase_pct,
                'annual_increase_factor': line.factor,
                'next_review_date': self.date + relativedelta(years=1),
            }
            if line.is_promotion:
                vals.update(job_grade_id=line.job_grade_id.id, last_promotion_date=self.date)
            version.write(vals)
            body = self.env._('Compensation review effective %(date)s: basic %(old)s → %(new)s',
                              date=self.date, old=f'{line.current_basic:,.2f}', new=f'{line.new_basic:,.2f}')
            if line.is_promotion:
                body += ' ' + self.env._('(promoted to %s)', line.job_grade_id.display_name)
            employee.message_post(body=body)
        return {'type': 'ir.actions.act_window_close'}


class HrCompensationReviewLine(models.TransientModel):
    _name = 'hr.compensation.review.line'
    _description = 'Compensation Review Line'

    review_id = fields.Many2one('hr.compensation.review', required=True, ondelete='cascade')
    currency_id = fields.Many2one(related='review_id.currency_id')
    employee_id = fields.Many2one('hr.employee', required=True)
    current_grade_id = fields.Many2one(related='employee_id.job_grade_id', string='Current Category')
    job_grade_id = fields.Many2one('hr.job.grade', string='New Category')
    is_promotion = fields.Boolean(compute='_compute_proposal')
    current_basic = fields.Monetary(related='employee_id.wage', string='Current Basic')
    increase_pct = fields.Float('Increase (%)')
    factor = fields.Float('Factor', default=1.0)
    proposed_basic = fields.Monetary('Proposed Basic', compute='_compute_proposal')
    new_basic = fields.Monetary('New Basic', compute='_compute_new_basic', store=True, readonly=False)
    increase_amount = fields.Monetary('Increase', compute='_compute_increase')
    increase_rate = fields.Float('Increase Rate (%)', compute='_compute_increase', digits=(16, 2))
    warning = fields.Char(compute='_compute_increase')

    @api.depends('employee_id', 'job_grade_id', 'increase_pct', 'factor')
    def _compute_proposal(self):
        for line in self:
            grade = line.job_grade_id
            line.is_promotion = bool(grade and grade != line.employee_id.job_grade_id)
            base = line.employee_id.wage
            if grade and base < grade.starting_basic:
                base = grade.starting_basic
            amount = base * (1 + line.increase_pct / 100.0 * line.factor)
            line.proposed_basic = line.currency_id.round(grade._cap(amount) if grade else amount)

    @api.depends('proposed_basic')
    def _compute_new_basic(self):
        for line in self:
            line.new_basic = line.proposed_basic

    @api.depends('new_basic', 'current_basic', 'job_grade_id')
    def _compute_increase(self):
        for line in self:
            line.increase_amount = line.new_basic - line.current_basic
            line.increase_rate = line.increase_amount / line.current_basic * 100 if line.current_basic else 0.0
            cap = line.job_grade_id.basic_cap
            line.warning = 'Above the basic cap' if cap and line.new_basic > cap else (
                'Reached the cap' if cap and line.new_basic == cap and line.increase_pct and line.factor else False)
