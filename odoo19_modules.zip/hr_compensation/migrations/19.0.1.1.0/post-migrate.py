def migrate(cr, version):
    """Nothing is paid by default anymore: the seeded allowance types are no longer recurring earnings
    unless the user gave them an amount."""
    cr.execute("""
        UPDATE hr_allowance_type t
           SET auto_apply = FALSE
          FROM ir_model_data d
         WHERE d.model = 'hr.allowance.type' AND d.res_id = t.id AND d.module = 'hr_compensation'
           AND t.auto_apply AND COALESCE(t.default_value, 0) = 0
    """)
