from odoo import SUPERUSER_ID, api


def migrate(cr, version):
    """The variable incentive changes every month: it is now entered on the payslip (Manual Amounts)."""
    env = api.Environment(cr, SUPERUSER_ID, {})
    allowance = env.ref('hr_compensation.allowance_variable_incentive', raise_if_not_found=False)
    if allowance:
        allowance.active = False
