from odoo import api, fields, models
from odoo.exceptions import ValidationError

GROUP = 'hr.group_hr_manager'

ELIGIBILITY_SELECTION = [
    ('always', 'Always'),
    ('remote_site_eligible', 'Remote Site Allowance Eligible'),
    ('transportation_eligible', 'Transportation Reimbursement Eligible'),
    ('owns_car', 'Owns Car'),
    ('fixed_incentive_eligible', 'Fixed Incentive Eligible'),
    ('variable_incentive_eligible', 'Variable Incentive Eligible'),
    ('sales_incentive_eligible', 'Sales Incentive Eligible'),
]


class HrAllowanceType(models.Model):
    _name = 'hr.allowance.type'
    _description = 'Allowance Type'
    _order = 'sequence, id'

    name = fields.Char(required=True, translate=True)
    code = fields.Char(required=True, help='Unique code, also used as the payslip input and salary rule code.')
    sequence = fields.Integer(default=10)
    active = fields.Boolean(default=True)
    calculation = fields.Selection([
        ('fixed', 'Fixed Amount'),
        ('percent', 'Percentage of Basic Salary'),
    ], required=True, default='fixed')
    default_value = fields.Float('Default Amount / %', help='Used when the allowance is added to a grade or an employee.')
    eligibility = fields.Selection(ELIGIBILITY_SELECTION, string='Paid When', required=True, default='always',
                                   help='The allowance is only added to the gross salary and the payslip when the employee has this flag.')
    in_gross = fields.Boolean('Part of Gross Salary', default=True,
                              help='Untick for allowances paid on top of the gross salary (e.g. reimbursements, incentives).')
    auto_apply = fields.Boolean(
        'Recurring Earning', help='Paid every month to every employee who has the "Paid When" flag, with the '
                                  'default amount, without adding it on each employee. An allowance line on the '
                                  'employee replaces the default amount.')
    note = fields.Text()

    _code_unique = models.Constraint('UNIQUE(code)', 'The allowance code must be unique.')

    @api.constrains('code')
    def _check_code(self):
        for allowance in self:
            if not allowance.code.replace('_', '').isalnum() or not allowance.code.isupper():
                raise ValidationError('The allowance code must be in capital letters, digits and "_" only (e.g. HOUSING).')

    def _compute_amount(self, value, wage):
        self.ensure_one()
        return wage * value / 100.0 if self.calculation == 'percent' else value

    # allowance type -> words of the localization contract field paying the same allowance
    LOCALIZATION_FIELD_WORDS = {
        'allowance_meals': ('meal',),
        'allowance_transport': ('transport',),
        'allowance_housing': ('housing',),
        'allowance_fixed_incentive': ('fixed_production',),
        'allowance_variable_incentive': ('variable_production',),
    }

    @api.model
    def _archive_localization_duplicates(self):
        """When the payroll localization (e.g. Egypt) has its own contract field for an allowance, archive
        our allowance type: each allowance is entered in one place only, the localization field."""
        localization_fields = [name for name in self.env['hr.version']._fields if name.startswith('l10n_')]
        for xmlid, words in self.LOCALIZATION_FIELD_WORDS.items():
            allowance = self.env.ref(f'hr_compensation.{xmlid}', raise_if_not_found=False)
            if allowance and allowance.active and any(w in f for f in localization_fields for w in words):
                allowance.active = False

    def _is_paid_to(self, version):
        self.ensure_one()
        return self.eligibility == 'always' or bool(version[self.eligibility])

    @api.model_create_multi
    def create(self, vals_list):
        types = super().create(vals_list)
        types._recompute_gross()
        return types

    def write(self, vals):
        res = super().write(vals)
        self._recompute_gross()
        return res

    def _recompute_gross(self):
        """Recurring earnings are not lines of the employees: refresh the stored gross salaries."""
        Version = self.env['hr.version'].sudo()
        versions = Version.search([])
        for fname in ('gross_salary', 'allowances_amount'):
            self.env.add_to_compute(Version._fields[fname], versions)
        Version.flush_model(['gross_salary', 'allowances_amount'])
        self.env['hr.employee'].invalidate_model(['gross_salary', 'allowances_amount'])


class _AllowanceLineMixin(models.AbstractModel):
    _name = 'hr.allowance.line.mixin'
    _description = 'Allowance Line'

    type_id = fields.Many2one('hr.allowance.type', string='Allowance', required=True, ondelete='restrict')
    calculation = fields.Selection(related='type_id.calculation')
    value = fields.Float('Amount / %', help='Amount for fixed allowances, percentage of the basic salary otherwise.')

    @api.onchange('type_id')
    def _onchange_type_id(self):
        if self.type_id and not self.value:
            self.value = self.type_id.default_value


class HrJobGradeAllowance(models.Model):
    _name = 'hr.job.grade.allowance'
    _inherit = 'hr.allowance.line.mixin'
    _description = 'Default Allowance of a Job Category'

    grade_id = fields.Many2one('hr.job.grade', required=True, ondelete='cascade', index=True)

    _unique_type = models.Constraint('UNIQUE(grade_id, type_id)', 'This allowance is already on the job category.')


class HrVersionAllowance(models.Model):
    _name = 'hr.version.allowance'
    _inherit = 'hr.allowance.line.mixin'
    _description = 'Employee Allowance'
    _order = 'sequence, id'

    version_id = fields.Many2one('hr.version', required=True, ondelete='cascade', index=True)
    sequence = fields.Integer(related='type_id.sequence', store=True)
    currency_id = fields.Many2one(related='version_id.currency_id')
    amount = fields.Monetary('Monthly Amount', compute='_compute_amount', store=True)
    is_paid = fields.Boolean('Paid', compute='_compute_amount', store=True,
                             help='False when the employee does not have the eligibility flag of this allowance.')
    in_gross = fields.Boolean(related='type_id.in_gross')

    _unique_type = models.Constraint('UNIQUE(version_id, type_id)', 'This allowance is already on the employee.')

    @api.depends('type_id.calculation', 'type_id.eligibility', 'value', 'version_id.wage',
                 'version_id.remote_site_eligible', 'version_id.transportation_eligible',
                 'version_id.owns_car', 'version_id.fixed_incentive_eligible',
                 'version_id.variable_incentive_eligible', 'version_id.sales_incentive_eligible')
    def _compute_amount(self):
        for line in self:
            version = line.version_id.sudo()
            amount = line.type_id._compute_amount(line.value, version.wage) if line.type_id else 0.0
            line.amount = version.currency_id.round(amount) if version.currency_id else amount
            line.is_paid = bool(line.type_id) and line.type_id._is_paid_to(version)
