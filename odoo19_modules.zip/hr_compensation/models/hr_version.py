from odoo import api, fields, models

GROUP = 'hr.group_hr_manager'


class HrVersion(models.Model):
    """Compensation data lives on the version so every raise or promotion keeps its history."""
    _inherit = 'hr.version'

    job_grade_id = fields.Many2one('hr.job.grade', string='Job Category', groups=GROUP, tracking=True)
    job_family_id = fields.Many2one(related='job_grade_id.family_id', string='Job Family', store=True, groups=GROUP)
    years_experience = fields.Integer('Years of Experience', groups=GROUP,
                                      help='Total professional experience when hired, used for the salary proposal.')
    last_promotion_date = fields.Date('Last Promotion Date', groups=GROUP)
    next_review_date = fields.Date('Next Review Date', groups=GROUP)
    starting_basic = fields.Monetary(related='job_grade_id.starting_basic', string='Starting Basic', groups=GROUP, aggregator='avg')
    basic_cap = fields.Monetary(related='job_grade_id.basic_cap', string='Basic Cap', groups=GROUP, aggregator='avg')
    annual_increase_pct = fields.Float('Annual Increase (%)', groups=GROUP, tracking=True)
    annual_increase_factor = fields.Float(
        'Annual Increase Factor', default=1.0, groups=GROUP, tracking=True,
        help='Performance multiplier of the annual increase: 0 = no increase, 1 = full increase, 1.5 = 150%.')
    proposed_basic = fields.Monetary('Proposed Basic (New Hire)', compute='_compute_proposed_basic', groups=GROUP,
                                     help='Starting basic of the grade adjusted by the years of experience, capped at the basic cap.')
    calculated_basic = fields.Monetary('Calculated Basic Salary', compute='_compute_calculated_basic', groups=GROUP,
                                       help='Basic salary after the next annual increase: basic x (1 + increase % x factor), capped at the basic cap.')
    band_position = fields.Float('Position in Band (%)', compute='_compute_band', groups=GROUP, aggregator='avg')
    band_status = fields.Selection([('below', 'Below band'), ('in', 'Within band'), ('above', 'Above cap')],
                                   compute='_compute_band', string='Band Status', groups=GROUP)

    fixed_allowance = fields.Monetary('Fixed Allowance', groups=GROUP, tracking=True)
    allowance_ids = fields.One2many('hr.version.allowance', 'version_id', string='Allowances', copy=True, groups=GROUP)
    allowances_amount = fields.Monetary('Other Allowances', compute='_compute_gross_salary', store=True, groups=GROUP)
    incentive_budget = fields.Monetary('Incentive Budget', groups=GROUP)
    gross_salary = fields.Monetary('Gross Salary', compute='_compute_gross_salary', store=True, groups=GROUP,
                                   help='Basic salary + fixed allowance + the paid allowances that are part of the gross.')

    attendance_eligible = fields.Boolean('Attendance Eligible', default=True, groups=GROUP,
                                         help='Late arrival and absence deductions apply to this employee.')
    overtime_eligible = fields.Boolean('Overtime Eligible', default=True, groups=GROUP,
                                       help='Overtime is paid to this employee (the attendance policy still decides how it is computed).')
    social_insurance = fields.Boolean(
        'Socially Insured', groups=GROUP, tracking=True,
        help='The social insurance contributions are deducted on the payslip.')
    income_tax = fields.Boolean(
        'Subject to Income Tax', groups=GROUP, tracking=True,
        help='The income tax is deducted on the payslip.')
    absence_deduction_base = fields.Selection([
        ('basic', 'Basic Salary Only'),
        ('gross', 'Basic Salary + Allowances'),
    ], string='Absence Deducted From', default='basic', required=True, groups=GROUP, tracking=True,
        help='Daily rate of the absences, unpaid and sick leaves and penalties in days: '
             'basic salary / days per month, or gross salary (basic + fixed allowance + allowances) / days per month.')
    life_insurance = fields.Boolean('Life Insurance', groups=GROUP, tracking=True)
    life_insurance_amount = fields.Monetary('Life Insurance Amount', groups=GROUP, tracking=True,
                                            help='Monthly amount on the payslip.')
    medical_insurance = fields.Boolean('Medical Insurance', groups=GROUP, tracking=True)
    medical_insurance_amount = fields.Monetary('Medical Insurance Amount', groups=GROUP, tracking=True,
                                               help='Monthly amount on the payslip.')
    stamp_tax = fields.Boolean('Stamp Tax', groups=GROUP, tracking=True)
    stamp_tax_amount = fields.Monetary('Stamp Tax Amount', groups=GROUP, tracking=True,
                                       help='Monthly amount deducted on the payslip.')
    fixed_incentive_eligible = fields.Boolean('Fixed Incentive Eligible', groups=GROUP)
    variable_incentive_eligible = fields.Boolean('Variable Incentive Eligible', groups=GROUP)
    sales_incentive_eligible = fields.Boolean('Sales Incentive Eligible', groups=GROUP)
    remote_site_eligible = fields.Boolean('Remote Site Allowance Eligible', groups=GROUP)
    transportation_eligible = fields.Boolean('Transportation Reimbursement Eligible', groups=GROUP)
    owns_car = fields.Boolean('Owns Car', groups=GROUP)

    @api.depends('job_grade_id.starting_basic', 'job_grade_id.basic_cap', 'job_grade_id.annual_increase_pct',
                 'job_grade_id.experience_method', 'job_grade_id.max_experience_years', 'years_experience')
    def _compute_proposed_basic(self):
        for version in self:
            version.proposed_basic = version.job_grade_id._proposed_basic(version.years_experience) \
                if version.job_grade_id else 0.0

    @api.depends('wage', 'annual_increase_pct', 'annual_increase_factor', 'job_grade_id.basic_cap')
    def _compute_calculated_basic(self):
        for version in self:
            amount = version.wage * (1 + version.annual_increase_pct / 100.0 * version.annual_increase_factor)
            if version.job_grade_id:
                amount = version.job_grade_id._cap(amount)
            version.calculated_basic = version.currency_id.round(amount) if version.currency_id else amount

    @api.depends('wage', 'job_grade_id.starting_basic', 'job_grade_id.basic_cap')
    def _compute_band(self):
        for version in self:
            grade = version.job_grade_id
            if not grade:
                version.band_position, version.band_status = 0.0, False
                continue
            if version.wage < grade.starting_basic:
                version.band_status = 'below'
            elif grade.basic_cap and version.wage > grade.basic_cap:
                version.band_status = 'above'
            else:
                version.band_status = 'in'
            width = grade.basic_cap - grade.starting_basic
            version.band_position = (version.wage - grade.starting_basic) / width * 100 if width > 0 else 0.0

    @api.depends('wage', 'fixed_allowance', 'allowance_ids.amount', 'allowance_ids.is_paid', 'allowance_ids.in_gross',
                 'remote_site_eligible', 'transportation_eligible', 'owns_car', 'fixed_incentive_eligible',
                 'variable_incentive_eligible', 'sales_incentive_eligible')
    def _compute_gross_salary(self):
        for version in self:
            version.allowances_amount = sum(
                amount for allowance, amount in version._effective_allowances() if allowance.in_gross)
            version.gross_salary = version.wage + version.fixed_allowance + version.allowances_amount

    def _effective_allowances(self):
        """[(allowance type, monthly amount)] paid to the employee: the allowance lines of the employee
        plus the recurring earnings of the flags the employee has."""
        self.ensure_one()
        version = self.sudo()
        result = [(line.type_id, line.amount) for line in version.allowance_ids
                  if line.is_paid and line.amount and line.type_id.active]
        own_types = version.allowance_ids.type_id
        recurring = self.env['hr.allowance.type'].sudo().search([('auto_apply', '=', True), ('id', 'not in', own_types.ids)])
        for allowance in recurring.filtered(lambda t: t._is_paid_to(version)):
            amount = allowance._compute_amount(allowance.default_value, version.wage)
            if version.currency_id:
                amount = version.currency_id.round(amount)
            if amount:
                result.append((allowance, amount))
        return result
