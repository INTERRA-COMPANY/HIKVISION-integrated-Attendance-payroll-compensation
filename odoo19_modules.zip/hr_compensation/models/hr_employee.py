from dateutil.relativedelta import relativedelta

from odoo import api, fields, models
from odoo.exceptions import UserError

GROUP = 'hr.group_hr_manager'


class HrEmployee(models.Model):
    _inherit = 'hr.employee'

    hiring_date = fields.Date('Hiring Date', groups='hr.group_hr_user', tracking=True)
    years_of_service = fields.Float('Years of Service', compute='_compute_years_of_service', groups='hr.group_hr_user',
                                    digits=(16, 1))

    # compensation fields stored on the current version (see hr.version)
    job_grade_id = fields.Many2one(readonly=False, related='version_id.job_grade_id', inherited=True, groups=GROUP)
    job_family_id = fields.Many2one(related='version_id.job_family_id', inherited=True, groups=GROUP)
    years_experience = fields.Integer(readonly=False, related='version_id.years_experience', inherited=True, groups=GROUP)
    last_promotion_date = fields.Date(readonly=False, related='version_id.last_promotion_date', inherited=True, groups=GROUP)
    next_review_date = fields.Date(readonly=False, related='version_id.next_review_date', inherited=True, groups=GROUP)
    starting_basic = fields.Monetary(related='version_id.starting_basic', inherited=True, groups=GROUP)
    basic_cap = fields.Monetary(related='version_id.basic_cap', inherited=True, groups=GROUP)
    annual_increase_pct = fields.Float(readonly=False, related='version_id.annual_increase_pct', inherited=True, groups=GROUP)
    annual_increase_factor = fields.Float(readonly=False, related='version_id.annual_increase_factor', inherited=True, groups=GROUP)
    proposed_basic = fields.Monetary(related='version_id.proposed_basic', inherited=True, groups=GROUP)
    calculated_basic = fields.Monetary(related='version_id.calculated_basic', inherited=True, groups=GROUP)
    band_position = fields.Float(related='version_id.band_position', inherited=True, groups=GROUP)
    band_status = fields.Selection(related='version_id.band_status', inherited=True, groups=GROUP)
    fixed_allowance = fields.Monetary(readonly=False, related='version_id.fixed_allowance', inherited=True, groups=GROUP)
    allowances_amount = fields.Monetary(related='version_id.allowances_amount', inherited=True, groups=GROUP)
    incentive_budget = fields.Monetary(readonly=False, related='version_id.incentive_budget', inherited=True, groups=GROUP)
    gross_salary = fields.Monetary(related='version_id.gross_salary', inherited=True, groups=GROUP)
    attendance_eligible = fields.Boolean(readonly=False, related='version_id.attendance_eligible', inherited=True, groups=GROUP)
    overtime_eligible = fields.Boolean(readonly=False, related='version_id.overtime_eligible', inherited=True, groups=GROUP)
    social_insurance = fields.Boolean(readonly=False, related='version_id.social_insurance', inherited=True, groups=GROUP)
    income_tax = fields.Boolean(readonly=False, related='version_id.income_tax', inherited=True, groups=GROUP)
    absence_deduction_base = fields.Selection(readonly=False, related='version_id.absence_deduction_base', inherited=True, groups=GROUP)
    life_insurance = fields.Boolean(readonly=False, related='version_id.life_insurance', inherited=True, groups=GROUP)
    life_insurance_amount = fields.Monetary(readonly=False, related='version_id.life_insurance_amount', inherited=True, groups=GROUP)
    medical_insurance = fields.Boolean(readonly=False, related='version_id.medical_insurance', inherited=True, groups=GROUP)
    medical_insurance_amount = fields.Monetary(readonly=False, related='version_id.medical_insurance_amount', inherited=True, groups=GROUP)
    stamp_tax = fields.Boolean(readonly=False, related='version_id.stamp_tax', inherited=True, groups=GROUP)
    stamp_tax_amount = fields.Monetary(readonly=False, related='version_id.stamp_tax_amount', inherited=True, groups=GROUP)
    fixed_incentive_eligible = fields.Boolean(readonly=False, related='version_id.fixed_incentive_eligible', inherited=True, groups=GROUP)
    variable_incentive_eligible = fields.Boolean(readonly=False, related='version_id.variable_incentive_eligible', inherited=True, groups=GROUP)
    sales_incentive_eligible = fields.Boolean(readonly=False, related='version_id.sales_incentive_eligible', inherited=True, groups=GROUP)
    remote_site_eligible = fields.Boolean(readonly=False, related='version_id.remote_site_eligible', inherited=True, groups=GROUP)
    transportation_eligible = fields.Boolean(readonly=False, related='version_id.transportation_eligible', inherited=True, groups=GROUP)
    owns_car = fields.Boolean(readonly=False, related='version_id.owns_car', inherited=True, groups=GROUP)

    @api.model_create_multi
    def create(self, vals_list):
        # hr writes the version values a second time after creating the employee, which would
        # duplicate one2many create commands: set the allowances once the employee exists
        vals_list = [dict(vals) for vals in vals_list]
        allowances = [vals.pop('allowance_ids', None) for vals in vals_list]
        employees = super().create(vals_list)
        for employee, commands in zip(employees, allowances):
            if commands:
                employee.version_id.write({'allowance_ids': commands})
        return employees

    @api.depends('hiring_date')
    def _compute_years_of_service(self):
        today = fields.Date.context_today(self)
        for employee in self:
            if employee.hiring_date and employee.hiring_date <= today:
                delta = relativedelta(today, employee.hiring_date)
                employee.years_of_service = delta.years + delta.months / 12.0
            else:
                employee.years_of_service = 0.0

    @api.onchange('job_grade_id')
    def _onchange_job_grade_id(self):
        grade = self.job_grade_id
        if not grade:
            return
        for name, value in grade._defaults_for_employee().items():
            self[name] = value
        self.allowance_ids = grade._allowance_commands()
        if not self.wage:
            self.wage = grade._proposed_basic(self.years_experience)

    @api.onchange('years_experience')
    def _onchange_years_experience(self):
        if self.job_grade_id and not self._origin.wage:
            self.wage = self.job_grade_id._proposed_basic(self.years_experience)

    @api.onchange('hiring_date', 'last_promotion_date')
    def _onchange_review_date(self):
        reference = self.last_promotion_date or self.hiring_date
        if reference and not self.next_review_date:
            self.next_review_date = reference + relativedelta(years=1)

    def action_apply_proposed_basic(self):
        for employee in self:
            if not employee.job_grade_id:
                raise UserError(self.env._('%s: choose a job category first.', employee.name))
            employee.wage = employee.proposed_basic

    def action_apply_grade_defaults(self):
        for employee in self.filtered('job_grade_id'):
            employee.write(dict(employee.job_grade_id._defaults_for_employee(),
                                allowance_ids=employee.job_grade_id._allowance_commands()))

    def action_open_compensation_review(self):
        return {
            'type': 'ir.actions.act_window', 'name': self.env._('Compensation Review'), 'res_model': 'hr.compensation.review',
            'view_mode': 'form', 'target': 'new', 'context': {'default_employee_ids': self.ids},
        }

    def action_print_compensation_card(self):
        return self.env.ref('hr_compensation.action_report_compensation_card').report_action(self)
