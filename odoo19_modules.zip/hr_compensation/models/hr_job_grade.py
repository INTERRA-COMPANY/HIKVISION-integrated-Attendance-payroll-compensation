from odoo import api, fields, models
from odoo.exceptions import ValidationError

ELIGIBILITY_FIELDS = [
    'attendance_eligible', 'overtime_eligible', 'fixed_incentive_eligible', 'variable_incentive_eligible',
    'sales_incentive_eligible', 'remote_site_eligible', 'transportation_eligible',
]


class HrJobFamily(models.Model):
    _name = 'hr.job.family'
    _description = 'Job Family'
    _order = 'sequence, name'

    name = fields.Char(required=True, translate=True)
    code = fields.Char()
    sequence = fields.Integer(default=10)
    active = fields.Boolean(default=True)
    grade_ids = fields.One2many('hr.job.grade', 'family_id', string='Job Categories')

    _name_unique = models.Constraint('UNIQUE(name)', 'A job family with this name already exists.')


class HrJobGrade(models.Model):
    _name = 'hr.job.grade'
    _description = 'Job Category (Grade)'
    _order = 'family_id, level, name'

    name = fields.Char('Job Category', required=True, translate=True)
    code = fields.Char()
    active = fields.Boolean(default=True)
    family_id = fields.Many2one('hr.job.family', string='Job Family', required=True, index=True)
    level = fields.Integer(help='Grade level inside the family, used for ordering and promotions (1 = lowest).')
    company_id = fields.Many2one('res.company', default=lambda self: self.env.company)
    currency_id = fields.Many2one('res.currency', related='company_id.currency_id')

    starting_basic = fields.Monetary('Starting Basic', required=True, help='Basic salary for a new hire with no experience.')
    basic_cap = fields.Monetary('Basic Cap', help='Maximum basic salary in this grade. Leave 0 for no cap.')
    annual_increase_pct = fields.Float('Annual Increase (%)', default=5.0)
    experience_method = fields.Selection([
        ('compound', 'Compound: starting basic x (1 + increase %) ^ years'),
        ('linear', 'Linear: starting basic x (1 + increase % x years)'),
        ('none', 'Ignore experience'),
    ], string='Experience in New-Hire Proposal', default='compound', required=True)
    max_experience_years = fields.Integer('Max Counted Years', default=0, help='0 = count all years of experience.')

    default_fixed_allowance = fields.Monetary('Default Fixed Allowance')
    allowance_ids = fields.One2many('hr.job.grade.allowance', 'grade_id', string='Default Allowances')
    default_incentive_budget = fields.Monetary('Default Incentive Budget')
    attendance_eligible = fields.Boolean('Attendance Eligible', default=True)
    overtime_eligible = fields.Boolean('Overtime Eligible', default=True)
    fixed_incentive_eligible = fields.Boolean('Fixed Incentive Eligible')
    variable_incentive_eligible = fields.Boolean('Variable Incentive Eligible')
    sales_incentive_eligible = fields.Boolean('Sales Incentive Eligible')
    remote_site_eligible = fields.Boolean('Remote Site Allowance Eligible')
    transportation_eligible = fields.Boolean('Transportation Reimbursement Eligible')

    employee_count = fields.Integer(compute='_compute_employee_count')

    @api.depends('family_id')
    def _compute_display_name(self):
        for grade in self:
            grade.display_name = f'{grade.family_id.name} / {grade.name}' if grade.family_id else grade.name

    @api.constrains('starting_basic', 'basic_cap')
    def _check_band(self):
        for grade in self:
            if grade.starting_basic < 0 or grade.basic_cap < 0:
                raise ValidationError('Salary values cannot be negative.')
            if grade.basic_cap and grade.basic_cap < grade.starting_basic:
                raise ValidationError(f'{grade.display_name}: the basic cap must be higher than the starting basic.')

    def _compute_employee_count(self):
        counts = dict(self.env['hr.employee']._read_group(
            [('job_grade_id', 'in', self.ids)], ['job_grade_id'], ['__count']))
        for grade in self:
            grade.employee_count = counts.get(grade, 0)

    def action_view_employees(self):
        return {
            'type': 'ir.actions.act_window', 'name': self.display_name, 'res_model': 'hr.employee',
            'view_mode': 'list,form', 'domain': [('job_grade_id', '=', self.id)],
        }

    def _cap(self, amount):
        self.ensure_one()
        return min(amount, self.basic_cap) if self.basic_cap else amount

    def _proposed_basic(self, years_experience):
        """Basic salary offered to a new hire of this grade with the given experience."""
        self.ensure_one()
        years = max(years_experience or 0, 0)
        if self.max_experience_years:
            years = min(years, self.max_experience_years)
        rate = self.annual_increase_pct / 100.0
        if self.experience_method == 'compound':
            amount = self.starting_basic * (1 + rate) ** years
        elif self.experience_method == 'linear':
            amount = self.starting_basic * (1 + rate * years)
        else:
            amount = self.starting_basic
        return self.currency_id.round(self._cap(amount))

    def _defaults_for_employee(self):
        self.ensure_one()
        vals = {name: self[name] for name in ELIGIBILITY_FIELDS}
        vals.update({
            'annual_increase_pct': self.annual_increase_pct,
            'fixed_allowance': self.default_fixed_allowance,
            'incentive_budget': self.default_incentive_budget,
        })
        return vals

    def _allowance_commands(self):
        """Commands replacing the allowances of an employee version by the defaults of this grade."""
        self.ensure_one()
        return [(5, 0, 0)] + [(0, 0, {'type_id': line.type_id.id, 'value': line.value}) for line in self.allowance_ids]
