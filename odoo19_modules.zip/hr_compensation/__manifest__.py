{
    'name': 'Employee Compensation & Grading',
    'version': '19.0.1.4.0',
    'category': 'Human Resources/Employees',
    'summary': 'Job families, grades with salary bands, salary proposals for new hires and annual increase reviews',
    'description': """
Compensation & Grading
======================
* Job families and job categories (grades) with a starting basic and a basic cap.
* Salary proposal for new hires from the grade and the years of experience.
* Unlimited allowance types (fixed or % of basic, paid only with an eligibility flag), defaults per grade.
* Compensation tab on the employee: basic, allowances, gross, eligibility flags, band position.
* Annual review wizard: increase % x performance factor, capped at the grade cap, promotions,
  applied as a new employee version so the full salary history is kept.
* Compensation card report and salary band analysis.
""",
    'author': 'Custom',
    'license': 'LGPL-3',
    'depends': ['hr'],
    'data': [
        'security/ir.model.access.csv',
        'data/hr_allowance_type_data.xml',
        'views/hr_allowance_type_views.xml',
        'views/hr_job_grade_views.xml',
        'views/hr_employee_views.xml',
        'wizard/hr_compensation_review_views.xml',
        'report/hr_compensation_report.xml',
        'views/menus.xml',
    ],
    'post_init_hook': 'post_init_hook',
    'installable': True,
    'application': False,
}
