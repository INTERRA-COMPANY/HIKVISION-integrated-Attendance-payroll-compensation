from . import models
from . import wizard


def post_init_hook(env):
    env['hr.allowance.type']._archive_localization_duplicates()
