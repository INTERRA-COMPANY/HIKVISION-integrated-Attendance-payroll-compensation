from datetime import date

from unittest.mock import patch

from odoo.tests import Form, TransactionCase, tagged


@tagged('post_install', '-at_install')
class TestCompensation(TransactionCase):

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.family = cls.env['hr.job.family'].create({'name': 'Technical'})
        cls.tech3 = cls.env['hr.job.grade'].create({
            'name': 'Technician III', 'family_id': cls.family.id, 'level': 3,
            'starting_basic': 2500, 'basic_cap': 7000, 'annual_increase_pct': 5,
            'default_fixed_allowance': 4000, 'overtime_eligible': True, 'remote_site_eligible': True,
            'allowance_ids': [
                (0, 0, {'type_id': cls.env.ref('hr_compensation.allowance_remote_site').id, 'value': 500}),
                (0, 0, {'type_id': cls.env.ref('hr_compensation.allowance_housing').id, 'value': 10}),
                (0, 0, {'type_id': cls.env.ref('hr_compensation.allowance_car').id, 'value': 800}),
            ],
        })
        cls.tech4 = cls.env['hr.job.grade'].create({
            'name': 'Technician IV', 'family_id': cls.family.id, 'level': 4,
            'starting_basic': 6000, 'basic_cap': 10000, 'annual_increase_pct': 5,
        })

    def test_new_hire_form(self):
        form = Form(self.env['hr.employee'])
        form.name = 'New Technician'
        form.years_experience = 20
        form.job_grade_id = self.tech3
        self.assertEqual(form.wage, 6633.24)  # 2500 x 1.05^20, under the 7000 cap
        self.assertEqual(form.fixed_allowance, 4000)
        self.assertTrue(form.overtime_eligible)
        self.assertEqual(len(form.allowance_ids), 3)
        employee = form.save()
        # remote site 500 + housing 10% of basic; the car allowance needs "Owns Car"
        self.assertAlmostEqual(employee.allowances_amount, 500 + 663.32, places=2)
        self.assertAlmostEqual(employee.gross_salary, 6633.24 + 4000 + 500 + 663.32, places=2)
        employee.owns_car = True
        self.assertAlmostEqual(employee.gross_salary, 6633.24 + 4000 + 500 + 663.32 + 800, places=2)
        employee.wage = 7000
        self.assertEqual(employee.allowance_ids.filtered(lambda l: l.type_id.code == 'HOUSING').amount, 700)
        self.assertEqual(employee.band_status, 'in')
        self.assertAlmostEqual(employee.band_position, 100, places=2)  # basic raised to the 7000 cap above

    def test_recurring_earnings(self):
        incentive = self.env.ref('hr_compensation.allowance_fixed_incentive')
        # the variable incentive is archived (entered on the payslip): the sales incentive is used instead
        variable = self.env.ref('hr_compensation.allowance_sales_incentive')
        # nothing is paid by default
        employee0 = self.env['hr.employee'].create({'name': 'Nothing', 'wage': 5000, 'fixed_incentive_eligible': True})
        self.assertEqual(employee0.gross_salary, 5000)
        self.assertFalse(employee0.version_id._effective_allowances())
        (incentive | variable).write({'auto_apply': True})
        incentive.default_value = 1000
        variable.default_value = 300
        employee = self.env['hr.employee'].create({
            'name': 'Incentives', 'wage': 5000, 'fixed_incentive_eligible': True, 'sales_incentive_eligible': True})
        self.assertEqual(employee.gross_salary, 5000 + 1000)  # the sales incentive is not part of the gross
        self.assertEqual(sorted(a.code for a, _amount in employee.version_id._effective_allowances()),
                         ['FIXED_INCENTIVE', 'SALES_INCENTIVE'])
        incentive.default_value = 1500
        self.assertEqual(employee.gross_salary, 6500)
        employee.fixed_incentive_eligible = False
        self.assertEqual(employee.gross_salary, 5000)
        # a line on the employee replaces the default amount
        employee.write({'fixed_incentive_eligible': True, 'allowance_ids': [(0, 0, {'type_id': incentive.id, 'value': 200})]})
        self.assertEqual(employee.gross_salary, 5200)

    def test_cap_and_methods(self):
        self.assertEqual(self.tech3._proposed_basic(40), 7000)
        self.tech3.experience_method = 'linear'
        self.assertEqual(self.tech3._proposed_basic(10), 3750)
        self.tech3.max_experience_years = 4
        self.assertEqual(self.tech3._proposed_basic(10), 3000)

    def test_calculated_basic_like_screenshot(self):
        employee = self.env['hr.employee'].create({
            'name': 'Screenshot', 'job_grade_id': self.tech3.id, 'wage': 5000,
            'annual_increase_pct': 5, 'annual_increase_factor': 0})
        self.assertEqual(employee.calculated_basic, 5000)
        employee.annual_increase_factor = 1
        self.assertEqual(employee.calculated_basic, 5250)
        employee.wage = 6900
        self.assertEqual(employee.calculated_basic, 7000)

    def test_review_wizard_keeps_history(self):
        employee = self.env['hr.employee'].create({
            'name': 'Reviewed', 'job_grade_id': self.tech3.id, 'wage': 5000,
            'annual_increase_pct': 5, 'annual_increase_factor': 1, 'date_version': date(2025, 1, 1)})
        promoted = self.env['hr.employee'].create({
            'name': 'Promoted', 'job_grade_id': self.tech3.id, 'wage': 5000,
            'annual_increase_pct': 5, 'annual_increase_factor': 1, 'date_version': date(2025, 1, 1)})
        form = Form(self.env['hr.compensation.review'].with_context(
            default_employee_ids=(employee | promoted).ids))
        form.date = date(2026, 1, 1)
        with form.line_ids.edit(1) as line:
            line.job_grade_id = self.tech4
        review = form.save()
        line_by_employee = {l.employee_id: l for l in review.line_ids}
        self.assertEqual(line_by_employee[employee].new_basic, 5250)
        self.assertEqual(line_by_employee[promoted].new_basic, 6300)  # raised to 6000 then +5%
        self.assertEqual(review.total_increase, 250 + 1300)
        employee.write({'allowance_ids': [(0, 0, {
            'type_id': self.env.ref('hr_compensation.allowance_meals').id, 'value': 300})]})
        review.action_apply()
        self.assertEqual(employee.allowance_ids.type_id.code, 'MEALS')  # copied to the new version
        self.assertEqual(employee._get_version(date(2025, 6, 1)).allowance_ids.amount, 300)

        self.assertEqual(len(employee.version_ids), 2)
        self.assertEqual(employee.wage, 5250)
        self.assertEqual(employee.next_review_date, date(2027, 1, 1))
        self.assertEqual(employee._get_version(date(2025, 6, 1)).wage, 5000)
        self.assertEqual(promoted.job_grade_id, self.tech4)
        self.assertEqual(promoted.last_promotion_date, date(2026, 1, 1))
        self.assertEqual(promoted._get_version(date(2025, 6, 1)).job_grade_id, self.tech3)

    def test_localization_duplicates_archived(self):
        meals = self.env.ref('hr_compensation.allowance_meals')
        shift = self.env.ref('hr_compensation.allowance_shift')
        fields = dict(self.env['hr.version']._fields)
        fake = dict(fields, l10n_eg_meal_allowance=fields['wage'])
        with patch.object(type(self.env['hr.version']), '_fields', fake):
            self.env['hr.allowance.type']._archive_localization_duplicates()
        self.assertFalse(meals.active)
        self.assertTrue(shift.active)
