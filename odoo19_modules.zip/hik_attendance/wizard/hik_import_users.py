from odoo import api, fields, models
from odoo.exceptions import UserError

from ..models.isapi_client import IsapiError


class HikImportUsers(models.TransientModel):
    _name = 'hik.import.users'
    _description = 'Link Device Users to Employees'

    device_id = fields.Many2one('hik.device', required=True)
    line_ids = fields.One2many('hik.import.users.line', 'wizard_id')

    @api.model
    def default_get(self, fields_list):
        res = super().default_get(fields_list)
        device = self.env['hik.device'].browse(res.get('device_id') or self.env.context.get('default_device_id'))
        if not device or 'line_ids' not in fields_list:
            return res
        try:
            users = list(device._client().iter_users())
        except IsapiError as e:
            raise UserError(device._isapi_message(e))
        Employee = self.env['hr.employee'].with_context(active_test=False)
        lines = []
        for user in users:
            employee_no = str(user.get('employeeNo') or '').strip()
            name = (user.get('name') or '').strip()
            employee = Employee.search([('company_id', '=', device.company_id.id),
                                        ('hik_employee_no', '=', employee_no)], limit=1)
            if not employee and name:
                employee = Employee.search([('company_id', '=', device.company_id.id),
                                            ('name', '=ilike', name)], limit=1)
            lines.append((0, 0, {'employee_no': employee_no, 'device_name': name, 'employee_id': employee.id}))
        res['line_ids'] = lines
        return res

    def action_apply(self):
        for line in self.line_ids.filtered('employee_id'):
            if line.employee_id.hik_employee_no != line.employee_no:
                line.employee_id.hik_employee_no = line.employee_no
        self.env['hik.attendance.log'].search([('state', '=', 'unmatched')]).action_reprocess()
        return {'type': 'ir.actions.act_window_close'}


class HikImportUsersLine(models.TransientModel):
    _name = 'hik.import.users.line'
    _description = 'Device User'

    wizard_id = fields.Many2one('hik.import.users', required=True, ondelete='cascade')
    employee_no = fields.Char('Device Employee No.', required=True)
    device_name = fields.Char('Name on the Device')
    employee_id = fields.Many2one('hr.employee', string='Odoo Employee')
