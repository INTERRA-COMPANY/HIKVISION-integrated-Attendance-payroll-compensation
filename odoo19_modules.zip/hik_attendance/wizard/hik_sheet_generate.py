from odoo import api, fields, models
from odoo.exceptions import UserError


class HikSheetGenerate(models.TransientModel):
    _name = 'hik.sheet.generate'
    _description = 'Generate Monthly Attendance Sheets'

    company_id = fields.Many2one('res.company', default=lambda self: self.env.company, required=True)
    period_start_day = fields.Integer(related='company_id.hik_period_start_day', readonly=False)
    ref_date = fields.Date('Month', required=True, default=fields.Date.context_today,
                           help='Any day of the month: the period follows the attendance period start day.')
    date_from = fields.Date('From', compute='_compute_period', store=True, readonly=False, required=True)
    date_to = fields.Date('To', compute='_compute_period', store=True, readonly=False, required=True)
    employee_ids = fields.Many2many(
        'hr.employee', string='Employees',
        default=lambda self: self.env['hr.employee'].search([('hik_policy_id', '!=', False)]),
        domain=[('hik_policy_id', '!=', False)])

    @api.depends('ref_date', 'period_start_day')
    def _compute_period(self):
        for wizard in self:
            wizard.date_from, wizard.date_to = self.env['hik.attendance.sheet']._hik_period(
                wizard.ref_date, wizard.company_id)

    def action_generate(self):
        self.ensure_one()
        if not self.employee_ids:
            raise UserError(self.env._('Choose at least one employee with an attendance policy.'))
        Sheet = self.env['hik.attendance.sheet']
        sheets = Sheet
        for employee in self.employee_ids:
            sheet = Sheet.search([('employee_id', '=', employee.id),
                                  ('date_from', '=', self.date_from), ('date_to', '=', self.date_to)], limit=1)
            if not sheet:
                sheet = Sheet.create({
                    'employee_id': employee.id, 'policy_id': employee.hik_policy_id.id,
                    'company_id': employee.company_id.id,
                    'date_from': self.date_from, 'date_to': self.date_to,
                })
            if sheet.state == 'draft':
                sheet._compute_lines()
            sheets |= sheet
        return {
            'type': 'ir.actions.act_window', 'name': self.env._('Attendance Sheets'), 'res_model': 'hik.attendance.sheet',
            'view_mode': 'list,form', 'domain': [('id', 'in', sheets.ids)],
        }
