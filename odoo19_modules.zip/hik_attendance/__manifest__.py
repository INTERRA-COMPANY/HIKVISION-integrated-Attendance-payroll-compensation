{
    'name': 'Hikvision Attendance & Payroll Rules',
    'version': '19.0.1.2.0',
    'category': 'Human Resources/Attendances',
    'summary': 'Import Hikvision punches into Attendances and compute monthly late arrivals, absences and overtime',
    'description': """
Hikvision devices (ISAPI) for Odoo Attendances
==============================================
* Imports the punches automatically and turns them into check-ins and check-outs.
* Synchronises the employees between Odoo and the device.
* Attendance policies on top of the employee working schedule: grace period, late and early leave
  deduction tiers, monthly late exemptions, absences, missing punches.
* Overtime on working days, public holidays and weekly days off, with their own multipliers.
* Monthly sheet per employee with approval and lock, daily detailed reports with amounts.
""",
    'author': 'Custom',
    'license': 'LGPL-3',
    'depends': ['hr_attendance'],
    'external_dependencies': {'python': ['requests']},
    'data': [
        'security/hik_security.xml',
        'security/ir.model.access.csv',
        'data/hik_ruleset_data.xml',
        'data/hik_calendar_data.xml',
        'data/hik_policy_data.xml',
        'data/ir_cron_data.xml',
        'report/hik_report_templates.xml',
        'report/hik_report.xml',
        'views/hik_device_views.xml',
        'views/hik_log_views.xml',
        'views/hik_policy_views.xml',
        'views/hik_sheet_views.xml',
        'views/hr_employee_views.xml',
        'views/hr_attendance_views.xml',
        'views/res_config_settings_views.xml',
        'wizard/hik_sheet_generate_views.xml',
        'wizard/hik_import_users_views.xml',
        'views/menus.xml',
    ],
    'installable': True,
    'application': False,
}
