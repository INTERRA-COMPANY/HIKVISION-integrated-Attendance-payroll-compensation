from datetime import datetime
from unittest.mock import patch

import pytz

from odoo.tests import TransactionCase, tagged

from ..models import isapi_client


class FakeResponse:
    status_code = 200

    def __init__(self, data):
        self.data = data
        self.text = ''

    def json(self):
        return self.data


@tagged('post_install', '-at_install')
class TestDeviceSync(TransactionCase):

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.employee = cls.env['hr.employee'].create({
            'name': 'موظف', 'tz': 'Africa/Cairo', 'hik_employee_no': '12',
            'resource_calendar_id': cls.env.ref('hik_attendance.calendar_operations').id})
        cls.device = cls.env['hik.device'].create({
            'name': 'البوابة', 'host': '192.168.1.60', 'password': 'x', 'tz': 'Africa/Cairo',
            'sync_from': datetime(2026, 9, 1)})

    def test_pull_and_build_attendance(self):
        pages = [
            {'AcsEvent': {'responseStatusStrg': 'MORE', 'InfoList': [
                {'employeeNoString': '12', 'time': '2026-09-01T08:03:10+03:00', 'minor': 75, 'serialNo': 1},
                {'employeeNoString': '12', 'time': '2026-09-01T08:04:00+03:00', 'minor': 75, 'serialNo': 2},
            ]}},
            {'AcsEvent': {'responseStatusStrg': 'OK', 'InfoList': [
                {'employeeNoString': '12', 'time': '2026-09-01T18:30:00+03:00', 'minor': 75, 'serialNo': 3},
                {'employeeNoString': '99', 'time': '2026-09-01T09:00:00+03:00', 'minor': 75, 'serialNo': 4},
                {'time': '2026-09-01T09:00:00+03:00', 'minor': 76, 'serialNo': 5},
                {'employeeNoString': '12', 'time': '2026-09-02T08:00:00+03:00', 'minor': 75, 'serialNo': 6},
            ]}},
        ]
        with patch.object(isapi_client.requests, 'request', side_effect=[FakeResponse(p) for p in pages]):
            self.assertEqual(self.device._sync_events(), 5)
        self.env['hik.attendance.log']._process_pending()

        logs = self.env['hik.attendance.log'].search([('device_id', '=', self.device.id)])
        self.assertEqual(logs.filtered(lambda l: l.employee_no == '99').state, 'unmatched')
        attendances = self.env['hr.attendance'].search([('employee_id', '=', self.employee.id)], order='check_in')
        self.assertEqual(len(attendances), 2)
        first, second = attendances
        self.assertEqual(first.check_in, datetime(2026, 9, 1, 5, 3, 10))
        self.assertEqual(first.check_out, datetime(2026, 9, 1, 15, 30))
        self.assertTrue(first.hik_synced)
        # a past day with one punch only is closed and flagged
        self.assertEqual(second.check_out, second.check_in)
        self.assertTrue(second.hik_missing_punch)

        # syncing again does not duplicate anything
        with patch.object(isapi_client.requests, 'request', side_effect=[FakeResponse(p) for p in pages]):
            self.assertEqual(self.device._sync_events(), 0)

        # HR edits are kept even if the day is rebuilt
        first.check_out = datetime(2026, 9, 1, 14, 0)
        self.assertTrue(first.hik_manual)
        self.env['hr.attendance']._hik_rebuild_day(self.employee, datetime(2026, 9, 1).date())
        self.assertEqual(first.check_out, datetime(2026, 9, 1, 14, 0))

    def test_time_helpers(self):
        tz = pytz.timezone('Africa/Cairo')
        dt = isapi_client.parse_isapi_time('2026-09-01T08:00:00', tz)
        self.assertEqual(isapi_client.format_isapi_time(dt), '2026-09-01T08:00:00+03:00')

    def test_import_users_wizard(self):
        """Same steps as the UI: open the wizard from the device, keep the proposed matches, save."""
        from odoo.tests import Form
        other = self.env['hr.employee'].create({'name': 'محمد علي'})
        users = [{'employeeNo': '12', 'name': 'موظف'}, {'employeeNo': '7', 'name': 'محمد علي'},
                 {'employeeNo': '30', 'name': 'زائر'}]
        with patch.object(isapi_client.IsapiClient, 'iter_users', return_value=iter(users)):
            action = self.device.action_import_users()
            wizard_form = Form(self.env[action['res_model']].with_context(action['context']))
        self.assertEqual(len(wizard_form.line_ids), 3)
        wizard = wizard_form.save()
        self.assertEqual(sorted(wizard.line_ids.mapped('employee_no')), ['12', '30', '7'])
        wizard.action_apply()
        self.assertEqual(other.hik_employee_no, '7')
        self.assertEqual(self.employee.hik_employee_no, '12')

    def _import(self, events):
        with patch.object(isapi_client.requests, 'request',
                          side_effect=[FakeResponse({'AcsEvent': {'responseStatusStrg': 'OK', 'InfoList': events}})]):
            self.device._sync_events()
        self.env['hik.attendance.log']._process_pending()

    def test_device_is_the_only_source(self):
        manual = self.env['hr.attendance'].create({
            'employee_id': self.employee.id, 'check_in': datetime(2026, 9, 3, 6, 0), 'check_out': datetime(2026, 9, 3, 13, 0)})
        self._import([
            {'employeeNoString': '12', 'time': '2026-09-03T08:10:00+03:00'},
            {'employeeNoString': '12', 'time': '2026-09-03T17:05:00+03:00'},
        ])
        self.assertFalse(manual.exists())
        attendance = self.env['hr.attendance'].search([('employee_id', '=', self.employee.id)])
        self.assertEqual(len(attendance), 1)
        self.assertTrue(attendance.hik_synced)
        self.assertEqual(attendance.check_in, datetime(2026, 9, 3, 5, 10))

    def test_keep_other_attendances_when_disabled(self):
        self.device.replace_other_attendances = False
        manual = self.env['hr.attendance'].create({
            'employee_id': self.employee.id, 'check_in': datetime(2026, 9, 3, 6, 0), 'check_out': datetime(2026, 9, 3, 13, 0)})
        self._import([{'employeeNoString': '12', 'time': '2026-09-03T08:10:00+03:00'},
                      {'employeeNoString': '12', 'time': '2026-09-03T17:05:00+03:00'}])
        self.assertTrue(manual.exists())
        logs = self.env['hik.attendance.log'].search([('employee_id', '=', self.employee.id)])
        self.assertEqual(set(logs.mapped('note')), {'other_attendance'})
        # switching it on and processing again replaces the other attendance and clears the note
        self.device.replace_other_attendances = True
        logs.action_reprocess()
        self.assertFalse(manual.exists())
        self.assertFalse(any(logs.mapped('note')))
