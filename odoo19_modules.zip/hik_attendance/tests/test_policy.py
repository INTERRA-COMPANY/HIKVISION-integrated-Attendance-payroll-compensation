from datetime import date, datetime

from odoo.tests import TransactionCase, tagged

DAY = date(2026, 10, 5)  # Monday


def at(h, m, s=0):
    return datetime(2026, 10, 5, h, m, s)


@tagged('post_install', '-at_install')
class TestPolicyEngine(TransactionCase):

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.ops = cls.env.ref('hik_attendance.policy_operations')
        cls.admin = cls.env.ref('hik_attendance.policy_admin')

    def eval(self, policy, check_in, check_out, day_type='work', **kw):
        worked = int((check_out - check_in).total_seconds() // 60) if check_in and check_out else 0
        bounds = (at(9, 0), at(17, 0)) if policy == self.admin else (at(8, 0), at(17, 0))
        return policy._evaluate_day(DAY, day_type, check_in, check_out, worked, bounds=bounds, **kw)

    def test_on_time(self):
        res = self.eval(self.ops, at(8, 0, 59), at(17, 0))
        self.assertEqual(res['late_minutes'], 0)
        self.assertEqual(res['late_days_auto'], 0)

    def test_late_tiers(self):
        self.assertEqual(self.eval(self.ops, at(8, 1), at(17, 0))['late_days_auto'], 0.25)
        self.assertEqual(self.eval(self.ops, at(9, 0), at(17, 0))['late_days_auto'], 0.25)
        self.assertEqual(self.eval(self.ops, at(9, 1), at(17, 0))['late_days_auto'], 0.5)
        self.assertEqual(self.eval(self.ops, at(10, 1), at(17, 0))['late_days_auto'], 0.75)
        self.assertEqual(self.eval(self.ops, at(11, 30), at(17, 0))['late_days_auto'], 1.0)
        # admins start at 9
        self.assertEqual(self.eval(self.admin, at(8, 50), at(17, 0))['late_days_auto'], 0)
        self.assertEqual(self.eval(self.admin, at(9, 1), at(17, 0))['late_days_auto'], 0.25)

    def test_grace(self):
        self.ops.grace_minutes = 10
        self.assertEqual(self.eval(self.ops, at(8, 10), at(17, 0))['late_days_auto'], 0)
        res = self.eval(self.ops, at(8, 11), at(17, 0))
        self.assertEqual((res['late_minutes'], res['late_days_auto']), (11, 0.25))

    def test_workday_overtime_threshold(self):
        self.assertEqual(self.eval(self.ops, at(8, 0), at(17, 59))['ot_minutes_auto'], 0)
        self.assertEqual(self.eval(self.ops, at(8, 0), at(18, 0, 59))['ot_minutes_auto'], 0)
        res = self.eval(self.ops, at(8, 0), at(18, 1))
        self.assertEqual((res['ot_type'], res['ot_minutes_auto']), ('workday', 61))
        self.assertEqual(self.eval(self.ops, at(8, 0), at(20, 30))['ot_minutes_auto'], 210)

    def test_workday_overtime_options(self):
        self.ops.write({'ot_workday_from': 'threshold', 'ot_rounding': 30})
        self.assertEqual(self.eval(self.ops, at(8, 0), at(19, 25))['ot_minutes_auto'], 60)

    def test_early_arrival_overtime(self):
        # off by default: arriving early is never overtime
        self.assertEqual(self.eval(self.ops, at(6, 30), at(17, 0))['ot_minutes_auto'], 0)
        self.ops.write({'ot_early_arrival': True, 'ot_early_threshold': 30})
        self.assertEqual(self.eval(self.ops, at(7, 30), at(17, 0))['ot_minutes_auto'], 0)
        self.assertEqual(self.eval(self.ops, at(7, 29), at(17, 0))['ot_minutes_auto'], 31)
        # added to the evening overtime, same type
        res = self.eval(self.ops, at(7, 0), at(18, 1))
        self.assertEqual((res['ot_type'], res['ot_minutes_auto']), ('workday', 60 + 61))
        # no check-out: arrival time alone is not overtime
        self.assertEqual(self.eval(self.ops, at(6, 0), at(6, 0))['ot_minutes_auto'], 0)

    def test_admin_no_overtime(self):
        res = self.eval(self.admin, at(9, 0), at(21, 0))
        self.assertFalse(res['ot_type'])
        self.assertEqual(res['ot_minutes_auto'], 0)
        res = self.eval(self.admin, at(9, 0), at(13, 0), day_type='weekly_off')
        self.assertEqual(res['ot_minutes_auto'], 0)

    def test_friday_and_holiday(self):
        res = self.eval(self.ops, at(10, 30), at(15, 0), day_type='weekly_off')
        self.assertEqual((res['ot_type'], res['ot_minutes_auto']), ('weekly_off', 270))
        self.assertEqual(res['late_days_auto'], 0)
        res = self.eval(self.ops, at(9, 0), at(17, 0), day_type='holiday')
        self.assertEqual((res['ot_type'], res['ot_minutes_auto']), ('holiday', 480))

    def test_absence_and_missing_punch(self):
        res = self.eval(self.ops, None, None)
        self.assertEqual(res['absence_days_auto'], 1.0)
        res = self.eval(self.ops, at(8, 20), at(8, 20))
        self.assertTrue(res['missing_punch'])
        self.assertEqual(res['late_days_auto'], 0.25)
        # a single afternoon punch is a check-out: arrival unknown, no deduction
        res = self.eval(self.ops, at(17, 5), at(17, 5))
        self.assertTrue(res['missing_punch'])
        self.assertEqual(res['late_days_auto'], 0)
        self.ops.missing_punch_action = 'absent'
        self.assertEqual(self.eval(self.ops, at(8, 0), at(8, 0))['absence_days_auto'], 1.0)

    def test_partial_leave_moves_start(self):
        res = self.eval(self.ops, at(10, 5), at(17, 0), leaves=[(at(8, 0), at(10, 0))])
        self.assertEqual((res['late_minutes'], res['late_days_auto']), (5, 0.25))

    def test_early_cutoff_and_exemption_limit(self):
        self.env['hik.attendance.policy.tier'].create({
            'policy_id': self.ops.id, 'tier_type': 'early', 'from_minutes': 1, 'deduction_days': 0.25})
        self.ops.early_cutoff = 17 + 10 / 60  # 17:10
        res = self.eval(self.ops, at(8, 0), at(17, 5))
        self.assertEqual((res['early_minutes'], res['early_days_auto']), (5, 0.25))
        self.assertEqual(self.eval(self.ops, at(8, 0), at(17, 10))['early_days_auto'], 0)

    def test_early_leave_tiers(self):
        self.env['hik.attendance.policy.tier'].create({
            'policy_id': self.ops.id, 'tier_type': 'early', 'from_minutes': 1, 'deduction_days': 0.25})
        res = self.eval(self.ops, at(8, 0), at(16, 30))
        self.assertEqual((res['early_minutes'], res['early_days_auto']), (30, 0.25))
