from datetime import date, datetime

import pytz

from odoo.tests import TransactionCase, tagged

CAIRO = pytz.timezone('Africa/Cairo')


def utc(d, h, m=0):
    """Cairo local time on 2026-09-<d> -> naive UTC as stored by Odoo."""
    return CAIRO.localize(datetime(2026, 9, d, h, m)).astimezone(pytz.utc).replace(tzinfo=None)


@tagged('post_install', '-at_install')
class TestSheet(TransactionCase):

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.env.company.resource_calendar_id.tz = 'Africa/Cairo'
        cls.policy = cls.env.ref('hik_attendance.policy_operations')
        cls.employee = cls.env['hr.employee'].create({
            'name': 'عامل تشغيل', 'tz': 'Africa/Cairo', 'hik_policy_id': cls.policy.id, 'wage': 9000,
            'resource_calendar_id': cls.env.ref('hik_attendance.calendar_operations').id,
        })
        Attendance = cls.env['hr.attendance']

        def attend(d, h1, m1, h2, m2):
            Attendance.create({'employee_id': cls.employee.id, 'check_in': utc(d, h1, m1), 'check_out': utc(d, h2, m2)})

        attend(1, 8, 1, 18, 1)     # Tue: late 1 min, overtime 61 min
        attend(2, 9, 1, 17, 0)     # Wed: late 61 min
        # 3 Thu: absent
        attend(4, 10, 0, 14, 0)    # Fri: weekly off worked 4h
        attend(5, 8, 0, 17, 0)
        attend(6, 8, 0, 16, 0)     # Sun: public holiday worked 8h
        # 7 Mon: personal leave
        for d in range(8, 31):
            if date(2026, 9, d).weekday() != 4:
                attend(d, 8, 0, 17, 0)
        Leaves = cls.env['resource.calendar.leaves']
        Leaves.create({'name': 'إجازة رسمية', 'date_from': utc(6, 0), 'date_to': utc(6, 23, 59),
                       'company_id': cls.env.company.id})
        Leaves.create({'name': 'إجازة اعتيادية', 'date_from': utc(7, 0), 'date_to': utc(7, 23, 59),
                       'resource_id': cls.employee.resource_id.id, 'company_id': cls.env.company.id})

    def make_sheet(self):
        sheet = self.env['hik.attendance.sheet'].create({
            'employee_id': self.employee.id, 'policy_id': self.policy.id,
            'date_from': date(2026, 9, 1), 'date_to': date(2026, 9, 30)})
        sheet._compute_lines()
        return sheet

    def line(self, sheet, d):
        return sheet.line_ids.filtered(lambda l: l.date == date(2026, 9, d))

    def test_month(self):
        sheet = self.make_sheet()
        self.assertEqual(len(sheet.line_ids), 30)
        self.assertEqual(self.line(sheet, 4).day_type, 'weekly_off')
        self.assertEqual(self.line(sheet, 6).day_type, 'holiday')
        self.assertEqual(self.line(sheet, 7).day_type, 'leave')
        self.assertEqual(self.line(sheet, 11).day_type, 'weekly_off')
        self.assertFalse(self.line(sheet, 11).is_absent)

        self.assertEqual(self.line(sheet, 1).late_days, 0.25)
        self.assertEqual(self.line(sheet, 2).late_days, 0.5)
        self.assertEqual(self.line(sheet, 3).absence_days, 1)
        self.assertEqual(sheet.late_days, 0.75)
        self.assertEqual(sheet.absence_count, 1)
        self.assertEqual(sheet.deduction_days, 1.75)

        self.assertEqual(self.line(sheet, 1).ot_minutes, 61)
        self.assertEqual(sheet.ot_workday_minutes, 61)
        self.assertEqual(sheet.ot_weekly_off_minutes, 240)
        self.assertEqual(sheet.ot_holiday_minutes, 480)
        self.assertEqual(sheet.ot_total_minutes, 781)

    def test_manual_adjustments_survive_recompute(self):
        sheet = self.make_sheet()
        self.line(sheet, 2).write({'waive_deduction': True, 'waive_reason': 'إذن من المدير'})
        self.line(sheet, 5).write({'ot_manual': True, 'ot_minutes_manual': 120})
        sheet.action_compute()
        self.assertEqual(sheet.late_days, 0.25)
        self.assertEqual(self.line(sheet, 5).ot_minutes, 120)

    def test_free_late_and_approval(self):
        self.policy.write({'late_free_count': 1, 'ot_requires_approval': True})
        sheet = self.make_sheet()
        self.assertTrue(self.line(sheet, 1).late_free)
        self.assertEqual(sheet.late_days, 0.5)
        self.assertEqual(sheet.ot_total_minutes, 0)
        self.assertEqual(sheet.ot_pending_count, 3)
        sheet.action_approve_all_ot()
        self.assertEqual(sheet.ot_total_minutes, 781)

    def test_late_exemption_max_minutes(self):
        self.policy.write({'late_free_count': 2, 'late_free_max_minutes': 15})
        sheet = self.make_sheet()
        self.assertTrue(self.line(sheet, 1).late_free)      # 1 minute late: exempted
        self.assertFalse(self.line(sheet, 2).late_free)     # 61 minutes late: above the limit
        self.assertEqual(sheet.late_days, 0.5)

    def test_odoo_overtime_disabled(self):
        self.assertEqual(self.employee.version_id.ruleset_id, self.env.ref('hik_attendance.ruleset_policy_overtime'))
        self.assertFalse(self.env['hr.attendance.overtime.line'].search([('employee_id', '=', self.employee.id)]))

    def test_report_language(self):
        self.env['res.lang']._activate_lang('ar_001')
        self.env['ir.module.module']._load_module_terms(['hik_attendance'], ['ar_001'], overwrite=True)
        self.env.registry.clear_cache('templates')
        sheet = self.make_sheet()
        self.assertEqual(sheet._report_lang(), self.env.lang or self.env.user.lang)
        self.env.company.hik_report_lang = 'fixed'
        self.env.company.hik_report_lang_code = 'ar_001'
        self.assertEqual(sheet._report_lang(), 'ar_001')
        html = self.env['ir.actions.report']._render_qweb_html('hik_attendance.report_hik_deductions', sheet.ids)[0].decode()
        self.assertIn('dir="rtl"', html)
        self.assertIn('الثلاثاء', html)  # weekday in Arabic
        self.assertIn('كشف التأخيرات والخصومات', html)
        self.assertIn('ربع يوم', html)
        self.assertEqual(sheet.with_context(lang='ar_001')._fields['late_days'].get_description(
            sheet.with_context(lang='ar_001').env)['string'], 'خصم التأخير (يوم)')
        # English stays English
        self.env.company.hik_report_lang_code = 'en_US'
        html = self.env['ir.actions.report']._render_qweb_html('hik_attendance.report_hik_deductions', sheet.ids)[0].decode()
        self.assertIn('Late Arrivals and Deductions', html)
        self.assertIn('Quarter day', html)
        self.assertNotIn('dir="rtl"', html)

    def test_period(self):
        Sheet = self.env['hik.attendance.sheet']
        company = self.env.company
        self.assertEqual(Sheet._hik_period(date(2026, 10, 15), company), (date(2026, 10, 1), date(2026, 10, 31)))
        company.hik_period_start_day = 26
        self.assertEqual(Sheet._hik_period(date(2026, 10, 1), company), (date(2026, 9, 26), date(2026, 10, 25)))
        self.assertEqual(Sheet._hik_period(date(2026, 12, 27), company), (date(2026, 12, 26), date(2027, 1, 25)))
