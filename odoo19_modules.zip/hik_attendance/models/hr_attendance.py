from datetime import datetime, timedelta

import pytz

from odoo import api, fields, models


class HrAttendance(models.Model):
    _inherit = 'hr.attendance'

    hik_synced = fields.Boolean('From Device', readonly=True, copy=False)
    hik_manual = fields.Boolean(
        'Manually Edited', copy=False,
        help='Edited by hand after the device import: the synchronisation does not change it anymore.')
    hik_missing_punch = fields.Boolean('Missing Punch', readonly=True, copy=False)

    def write(self, vals):
        if not self.env.context.get('hik_sync') and {'check_in', 'check_out'} & set(vals):
            vals = dict(vals, hik_manual=True) if any(self.mapped('hik_synced')) else vals
            if 'check_out' in vals and vals.get('check_out'):
                vals['hik_missing_punch'] = False
        return super().write(vals)

    @api.model
    def _hik_rebuild_day(self, employee, day):
        """(Re)build the device attendance of one employee for one local day from its raw punches."""
        logs = self.env['hik.attendance.log']._day_punches(employee, day)
        if not logs:
            return
        self._hik_close_stale(employee)
        gap = timedelta(minutes=max(logs.mapped('device_id.min_punch_gap') or [0]))
        first, last = logs[0].punch_time, logs[-1].punch_time
        single = last - first < gap
        today = datetime.now(pytz.timezone(employee._get_tz())).date()

        day_attendances = self.search([('employee_id', '=', employee.id), ('date', '=', day)])
        device_attendances = day_attendances.filtered('hik_synced')
        if device_attendances.filtered('hik_manual'):
            return
        other_attendances = day_attendances - device_attendances
        if other_attendances:
            if not all(logs.device_id.mapped('replace_other_attendances')):
                logs.write({'note': 'other_attendance'})
                return
            other_attendances.sudo().unlink()
        logs.filtered('note').write({'note': False})

        vals = {
            'check_in': first,
            'check_out': first if single else last,
            'hik_missing_punch': single,
        }
        if single and day >= today:
            # the employee is probably still at work: keep the attendance open
            vals.update(check_out=False, hik_missing_punch=False)
        device_attendances = device_attendances.with_context(hik_sync=True)
        if device_attendances:
            device_attendances[1:].unlink()
            device_attendances[0].write(vals)
        else:
            self.with_context(hik_sync=True).create(dict(vals, employee_id=employee.id, hik_synced=True))

    @api.model
    def _hik_close_stale(self, employee=None):
        """Close device attendances left open on a previous day (the employee never punched out)."""
        domain = [('hik_synced', '=', True), ('check_out', '=', False)]
        if employee:
            domain.append(('employee_id', '=', employee.id))
        for attendance in self.search(domain):
            today = datetime.now(pytz.timezone(attendance.employee_id._get_tz())).date()
            if attendance.date < today:
                attendance.with_context(hik_sync=True).write({
                    'check_out': attendance.check_in, 'hik_missing_punch': True})
