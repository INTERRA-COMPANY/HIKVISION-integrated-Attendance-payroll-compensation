from datetime import datetime, time

from odoo import api, fields, models
from odoo.exceptions import ValidationError


def float_to_time(value):
    minutes = round(value * 60)
    if minutes >= 24 * 60:
        return time(23, 59, 59)
    return time(minutes // 60, minutes % 60)


def minutes_between(start, end):
    """Whole minutes from start to end (seconds are truncated, 0 if end <= start)."""
    if not start or not end or end <= start:
        return 0
    return int((end - start).total_seconds() // 60)


def calendar_day_bounds(calendar, day):
    """(start, end) naive datetimes of the working day in the calendar, or None for a day off.

    The working hours themselves live on the employee's Working Schedule (resource.calendar):
    the policy only holds the rules applied on top of it.
    """
    if not calendar:
        return None
    lines = calendar.attendance_ids.filtered(
        lambda a: a.dayofweek == str(day.weekday()) and not a.display_type and a.day_period != 'lunch')
    if calendar.two_weeks_calendar:
        week_type = str(calendar.env['resource.calendar.attendance'].get_week_type(day))
        lines = lines.filtered(lambda a: a.week_type == week_type)
    if not lines:
        return None
    return (datetime.combine(day, float_to_time(min(lines.mapped('hour_from')))),
            datetime.combine(day, float_to_time(max(lines.mapped('hour_to')))))


class HikAttendancePolicy(models.Model):
    _name = 'hik.attendance.policy'
    _description = 'Attendance Policy'
    _order = 'sequence, id'

    name = fields.Char(required=True, translate=True)
    sequence = fields.Integer(default=10)
    active = fields.Boolean(default=True)
    company_id = fields.Many2one('res.company', string='Company', default=lambda self: self.env.company)
    employee_count = fields.Integer('Employees', compute='_compute_employee_count')

    # ---------------------------------------------------------------- late arrival
    grace_minutes = fields.Integer(
        'Late Grace Period (minutes)', default=0,
        help='A late arrival up to this number of minutes is not deducted. 0 = every minute counts.')
    late_tier_ids = fields.One2many(
        'hik.attendance.policy.tier', 'policy_id', string='Late Arrival Deductions',
        domain=[('tier_type', '=', 'late')], context={'default_tier_type': 'late'})
    late_free_count = fields.Integer(
        'Monthly Late Exemption Count', default=0,
        help='The first N late arrivals of the period are shown on the reports without deduction. 0 = no exemption.')
    late_free_max_minutes = fields.Integer(
        'Monthly Late Exemption Max Minutes', default=0,
        help='Only late arrivals up to this number of minutes can use an exemption. 0 = any late arrival.')

    # ---------------------------------------------------------------- early leave
    early_cutoff = fields.Float(
        'Early Leave Cutoff Time', default=0.0,
        help='Leaving before this time is an early leave. Leave empty to use the end of the working schedule.')
    early_grace_minutes = fields.Integer('Early Leave Grace Period (minutes)', default=0)
    early_tier_ids = fields.One2many(
        'hik.attendance.policy.tier', 'policy_id', string='Early Leave Deductions',
        domain=[('tier_type', '=', 'early')], context={'default_tier_type': 'early'})

    # ---------------------------------------------------------------- absence
    absence_deduction_days = fields.Float('Absence Without Approval Deduction (days)', default=1.0)
    missing_punch_action = fields.Selection([
        ('late_only', 'Compute the late arrival from the check-in and flag the day'),
        ('review', 'Flag the day for review without any deduction'),
        ('absent', 'Count it as an absence'),
    ], string='Single Punch in a Day', default='late_only', required=True)

    # ---------------------------------------------------------------- overtime
    ot_workday = fields.Boolean('Working Day Overtime')
    ot_workday_threshold = fields.Integer(
        'Counted When Leaving More Than (minutes after the schedule)', default=60,
        help='Example: 60 = leaving at 18:00 or earlier gives no overtime, leaving at 18:01 does (schedule ending at 17:00).')
    ot_workday_from = fields.Selection([
        ('shift_end', 'From the end of the schedule'),
        ('threshold', 'After the threshold only'),
    ], string='Counted From', default='shift_end', required=True)
    ot_early_arrival = fields.Boolean(
        'Early Arrival Overtime',
        help='Count the time before the start of the working schedule as working day overtime. '
             'Off by default: arriving early is not overtime.')
    ot_early_threshold = fields.Integer(
        'Counted When Arriving More Than (minutes before the schedule)', default=30,
        help='Example: 30 with a schedule starting at 08:00 = arriving at 07:30 or later gives no overtime, '
             'arriving at 07:29 gives 31 minutes.')
    ot_holiday = fields.Boolean('Public Holiday Overtime')
    ot_weekly_off = fields.Boolean('Weekly Day Off Overtime')
    ot_min_minutes = fields.Integer('Minimum Overtime (minutes)', default=0, help='Shorter overtime is ignored. 0 = no minimum.')
    ot_rounding = fields.Integer(
        'Round Overtime Down to (minutes)', default=0,
        help='0 = to the minute. 15: 1:10 becomes 1:00. 30: 1:40 becomes 1:30.')
    ot_max_minutes_day = fields.Integer('Maximum Overtime per Day (minutes)', default=0, help='0 = no maximum.')
    ot_requires_approval = fields.Boolean(
        'Overtime Requires Approval',
        help='Overtime shows on the sheet but is only paid once approved.')

    @api.constrains('early_cutoff')
    def _check_values(self):
        for policy in self:
            if not 0 <= policy.early_cutoff < 24:
                raise ValidationError(self.env._('The early leave cutoff time must be a time of the day.'))

    def _compute_employee_count(self):
        counts = dict(self.env['hr.employee']._read_group(
            [('hik_policy_id', 'in', self.ids)], ['hik_policy_id'], ['__count']))
        for policy in self:
            policy.employee_count = counts.get(policy, 0)

    def action_view_employees(self):
        return {
            'type': 'ir.actions.act_window',
            'name': self.env._('Employees'),
            'res_model': 'hr.employee',
            'view_mode': 'list,form',
            'domain': [('hik_policy_id', '=', self.id)],
            'context': {'default_hik_policy_id': self.id},
        }

    # ---------------------------------------------------------------- helpers
    def _tier_days(self, tier_type, minutes):
        tiers = self.late_tier_ids if tier_type == 'late' else self.early_tier_ids
        matching = tiers.filtered(lambda t: t.from_minutes <= minutes)
        return max(matching, key=lambda t: t.from_minutes).deduction_days if matching else 0.0

    def _adjust_ot_minutes(self, minutes):
        if self.ot_rounding > 0:
            minutes -= minutes % self.ot_rounding
        if self.ot_max_minutes_day > 0:
            minutes = min(minutes, self.ot_max_minutes_day)
        if minutes < max(self.ot_min_minutes, 1):
            return 0
        return minutes

    # ---------------------------------------------------------------- engine
    def _evaluate_day(self, day, day_type, check_in=None, check_out=None, worked_minutes=0, leaves=(), bounds=None):
        """Apply this policy to one employee day.

        All datetimes are naive and expressed in the employee's local time.
        ``bounds`` is the (start, end) of the working schedule that day.
        ``check_in``/``check_out`` are the first and last punch of the day; a single
        punch is passed with ``check_out == check_in`` (or no check_out).
        ``leaves`` is a list of (start, end) partial time-off intervals of that day.
        """
        self.ensure_one()
        res = {
            'late_minutes': 0, 'early_minutes': 0,
            'late_days_auto': 0.0, 'early_days_auto': 0.0, 'absence_days_auto': 0.0,
            'missing_punch': False, 'ot_type': False, 'ot_minutes_auto': 0,
            'auto_note': False,
        }
        if day_type in ('holiday', 'weekly_off'):
            enabled = self.ot_holiday if day_type == 'holiday' else self.ot_weekly_off
            if enabled:
                res.update(ot_type=day_type, ot_minutes_auto=self._adjust_ot_minutes(worked_minutes))
            if check_in and (not check_out or check_out == check_in):
                res.update(missing_punch=True, auto_note='single_punch_day_off')
            return res
        if day_type in ('leave', 'out') or not bounds:
            return res

        shift_start, shift_end = bounds
        start, end = shift_start, shift_end
        if self.early_cutoff:
            end = datetime.combine(day, float_to_time(self.early_cutoff))
        for leave_start, leave_end in leaves:
            if leave_start <= start < leave_end:
                start = min(leave_end, end)
            if leave_start < end <= leave_end:
                end = max(leave_start, start)

        if not check_in:
            res['absence_days_auto'] = self.absence_deduction_days
            res['auto_note'] = 'absent'
            return res

        if not check_out or check_out == check_in:
            res['missing_punch'] = True
            if self.missing_punch_action == 'absent':
                res.update(absence_days_auto=self.absence_deduction_days, auto_note='single_punch_absent')
                return res
            if self.missing_punch_action == 'review' or check_in >= start + (end - start) / 2:
                res['auto_note'] = 'single_punch'
                return res
            res['auto_note'] = 'no_check_out'
            check_out = None

        late = minutes_between(start, check_in)
        res['late_minutes'] = late
        if late > self.grace_minutes:
            res['late_days_auto'] = self._tier_days('late', late)

        if self.ot_workday or self.ot_early_arrival:
            # set even without overtime so a manual overtime entry gets the right type
            res['ot_type'] = 'workday'
        if check_out:
            early = minutes_between(check_out, end)
            res['early_minutes'] = early
            if early > self.early_grace_minutes:
                res['early_days_auto'] = self._tier_days('early', early)
            overtime = 0
            if self.ot_workday:
                after_end = minutes_between(shift_end, check_out)
                if after_end > self.ot_workday_threshold:
                    if self.ot_workday_from == 'threshold':
                        after_end -= self.ot_workday_threshold
                    overtime += after_end
            if self.ot_early_arrival:
                before_start = minutes_between(check_in, shift_start)
                if before_start > self.ot_early_threshold:
                    overtime += before_start
            res['ot_minutes_auto'] = self._adjust_ot_minutes(overtime)
        return res


class HikAttendancePolicyTier(models.Model):
    _name = 'hik.attendance.policy.tier'
    _description = 'Deduction Tier'
    _order = 'from_minutes'

    policy_id = fields.Many2one('hik.attendance.policy', required=True, ondelete='cascade', index=True)
    tier_type = fields.Selection([('late', 'Late Arrival'), ('early', 'Early Leave')], required=True, default='late')
    from_minutes = fields.Integer('From (minutes)', required=True,
                                  help='The tier applies when the minutes are greater than or equal to this number.')
    deduction_days = fields.Float('Deduction (days)', required=True, digits=(16, 4),
                                  help='0.25 = quarter day, 0.5 = half day, 1 = full day.')

    _from_minutes_positive = models.Constraint('CHECK(from_minutes > 0)', 'A tier must start at one minute or more.')
