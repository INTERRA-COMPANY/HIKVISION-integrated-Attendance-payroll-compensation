from datetime import datetime, time, timedelta

import pytz

from odoo import api, fields, models


class HikAttendanceLog(models.Model):
    _name = 'hik.attendance.log'
    _description = 'Raw Device Punch'
    _order = 'punch_time desc, id desc'

    device_id = fields.Many2one('hik.device', string='Device', required=True, ondelete='cascade', index=True)
    company_id = fields.Many2one(related='device_id.company_id', store=True)
    employee_no = fields.Char('Device Employee No.', required=True, index=True)
    device_user_name = fields.Char('Name on the Device')
    employee_id = fields.Many2one('hr.employee', string='Employee', index=True)
    punch_time = fields.Datetime('Punch Time', required=True, index=True)
    event_minor = fields.Integer('Event Code')
    verify_mode = fields.Char('Verification Mode')
    serial_no = fields.Integer('Device Event No.')
    state = fields.Selection([
        ('new', 'New'),
        ('done', 'Processed'),
        ('unmatched', 'Employee Not Linked'),
    ], string='Status', default='new', required=True, index=True)
    note = fields.Selection([('other_attendance', 'Another attendance exists that day: not imported')], string='Note')

    _unique_punch = models.Constraint(
        'UNIQUE(device_id, employee_no, punch_time)', 'This punch is already imported.')

    def action_reprocess(self):
        self.write({'state': 'new', 'note': False})
        self._process_pending()

    @api.model
    def _process_pending(self):
        """Match pending logs to employees and rebuild the affected attendance days."""
        logs = self.search([('state', 'in', ('new', 'unmatched'))])
        if not logs:
            return
        employees = self.env['hr.employee'].with_context(active_test=False).search(
            [('hik_employee_no', 'in', list(set(logs.mapped('employee_no'))))])
        by_key = {(e.company_id.id, e.hik_employee_no): e for e in employees}
        days = set()
        for log in logs:
            employee = by_key.get((log.company_id.id, log.employee_no))
            if not employee:
                log.write({'state': 'unmatched', 'employee_id': False})
                continue
            log.write({'state': 'done', 'employee_id': employee.id})
            tz = pytz.timezone(employee._get_tz())
            days.add((employee, pytz.utc.localize(log.punch_time).astimezone(tz).date()))
        for employee, day in sorted(days, key=lambda d: (d[0].id, d[1])):
            self.env['hr.attendance']._hik_rebuild_day(employee, day)

    @api.model
    def _day_punches(self, employee, day):
        """UTC naive punch datetimes of an employee for a local calendar day."""
        tz = pytz.timezone(employee._get_tz())
        start = tz.localize(datetime.combine(day, time.min)).astimezone(pytz.utc).replace(tzinfo=None)
        stop = start + timedelta(days=1)
        logs = self.search([('employee_id', '=', employee.id), ('state', '=', 'done'),
                            ('punch_time', '>=', start), ('punch_time', '<', stop)], order='punch_time')
        return logs
