from odoo import api, fields, models


class ResCompany(models.Model):
    _inherit = 'res.company'

    hik_period_start_day = fields.Integer(
        string='Attendance Period Start Day', default=1,
        help='1 = from the first to the last day of the month. 26 = from the 26th of the previous month '
             'to the 25th of the month.')
    hik_report_lang = fields.Selection([
        ('user', 'Language of the user printing'),
        ('employee', 'Language of the employee'),
        ('fixed', 'Specific language'),
    ], string='Attendance Reports Language', default='user', required=True)
    hik_report_lang_code = fields.Selection(
        selection='_hik_lang_selection', string='Attendance Reports Fixed Language')

    @api.model
    def _hik_lang_selection(self):
        return self.env['res.lang'].get_installed()


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    hik_period_start_day = fields.Integer(related='company_id.hik_period_start_day', readonly=False)
    hik_report_lang = fields.Selection(related='company_id.hik_report_lang', readonly=False)
    hik_report_lang_code = fields.Selection(related='company_id.hik_report_lang_code', readonly=False)
