from collections import defaultdict
from datetime import datetime, time, timedelta

import pytz
from babel.dates import format_date as babel_format_date

from odoo import api, fields, models
from odoo.exceptions import UserError, ValidationError
from odoo.tools.misc import babel_locale_parse

from .hik_policy import calendar_day_bounds

DAY_TYPES = [
    ('work', 'Working Day'),
    ('weekly_off', 'Weekly Day Off'),
    ('holiday', 'Public Holiday'),
    ('leave', 'Time Off'),
    ('out', 'Outside Contract'),
]
OT_TYPES = [('workday', 'Working Day'), ('holiday', 'Public Holiday'), ('weekly_off', 'Weekly Day Off')]
AUTO_NOTES = [
    ('absent', 'Absent without approval'),
    ('single_punch', 'Single punch: to review'),
    ('no_check_out', 'No check-out: to review'),
    ('single_punch_absent', 'Single punch: counted as absence'),
    ('single_punch_day_off', 'Single punch on a day off: no overtime'),
]


def format_minutes(minutes):
    minutes = int(round(minutes or 0))
    return f'{minutes // 60}:{minutes % 60:02d}'


class HikAttendanceSheet(models.Model):
    _name = 'hik.attendance.sheet'
    _description = 'Monthly Attendance Sheet'
    _inherit = ['mail.thread']
    _order = 'date_from desc, employee_id'

    name = fields.Char(compute='_compute_name', store=True)
    employee_id = fields.Many2one('hr.employee', string='Employee', required=True, index=True)
    department_id = fields.Many2one(related='employee_id.department_id', store=True, string='Department')
    company_id = fields.Many2one('res.company', required=True, default=lambda self: self.env.company)
    policy_id = fields.Many2one('hik.attendance.policy', string='Attendance Policy', required=True, tracking=True)
    date_from = fields.Date('From', required=True)
    date_to = fields.Date('To', required=True)
    state = fields.Selection([('draft', 'Draft'), ('confirmed', 'Confirmed'), ('done', 'Locked')],
                             string='Status', default='draft', required=True, tracking=True, index=True)
    line_ids = fields.One2many('hik.attendance.sheet.line', 'sheet_id', string='Days')
    computed_until = fields.Date('Computed Until', readonly=True)
    apply_deductions = fields.Boolean(
        'Apply Attendance Deductions', default=True, readonly=True,
        help="From the employee card (Attendance Eligible) when the compensation module is installed.")
    apply_overtime = fields.Boolean(
        'Apply Overtime', default=True, readonly=True,
        help="From the employee card (Overtime Eligible) when the compensation module is installed.")

    work_days = fields.Integer('Working Days', compute='_compute_totals', store=True)
    present_days = fields.Integer('Days Present', compute='_compute_totals', store=True)
    absence_count = fields.Integer('Days Absent', compute='_compute_totals', store=True)
    leave_days = fields.Integer('Days of Time Off', compute='_compute_totals', store=True)
    missing_punch_count = fields.Integer('Days with Missing Punch', compute='_compute_totals', store=True)
    late_count = fields.Integer('Late Arrivals', compute='_compute_totals', store=True)
    late_minutes = fields.Integer('Late Minutes', compute='_compute_totals', store=True)
    late_days = fields.Float('Late Deduction (days)', compute='_compute_totals', store=True, digits=(16, 4))
    early_minutes = fields.Integer('Early Leave Minutes', compute='_compute_totals', store=True)
    early_days = fields.Float('Early Leave Deduction (days)', compute='_compute_totals', store=True, digits=(16, 4))
    absence_days = fields.Float('Absence Deduction (days)', compute='_compute_totals', store=True, digits=(16, 4))
    deduction_days = fields.Float('Total Deductions (days)', compute='_compute_totals', store=True, digits=(16, 4))
    ot_workday_minutes = fields.Integer('Working Day Overtime (minutes)', compute='_compute_totals', store=True)
    ot_holiday_minutes = fields.Integer('Public Holiday Overtime (minutes)', compute='_compute_totals', store=True)
    ot_weekly_off_minutes = fields.Integer('Weekly Day Off Overtime (minutes)', compute='_compute_totals', store=True)
    ot_total_minutes = fields.Integer('Total Overtime (minutes)', compute='_compute_totals', store=True)
    ot_pending_count = fields.Integer('Overtime Days to Approve', compute='_compute_totals', store=True)

    _check_dates = models.Constraint('CHECK(date_from <= date_to)', 'The start date must be before the end date.')

    @api.depends('employee_id', 'date_from', 'date_to')
    def _compute_name(self):
        for sheet in self:
            sheet.name = f'{sheet.employee_id.name or ""} ({sheet.date_from} → {sheet.date_to})'

    @api.constrains('employee_id', 'date_from', 'date_to')
    def _check_overlap(self):
        for sheet in self:
            if self.search_count([('id', '!=', sheet.id), ('employee_id', '=', sheet.employee_id.id),
                                  ('date_from', '<=', sheet.date_to), ('date_to', '>=', sheet.date_from)]):
                raise ValidationError(self.env._(
                    'Another attendance sheet of %(employee)s overlaps this period.', employee=sheet.employee_id.name))

    @api.depends('line_ids.day_type', 'line_ids.is_absent', 'line_ids.check_in', 'line_ids.missing_punch',
                 'line_ids.late_minutes', 'line_ids.late_days', 'line_ids.early_minutes', 'line_ids.early_days',
                 'line_ids.absence_days', 'line_ids.ot_type', 'line_ids.ot_minutes', 'line_ids.ot_pending')
    def _compute_totals(self):
        for sheet in self:
            lines = sheet.line_ids
            work = lines.filtered(lambda l: l.day_type == 'work')
            sheet.work_days = len(work)
            sheet.present_days = len(work.filtered('check_in'))
            sheet.absence_count = len(lines.filtered('is_absent'))
            sheet.leave_days = len(lines.filtered(lambda l: l.day_type == 'leave'))
            sheet.missing_punch_count = len(lines.filtered('missing_punch'))
            sheet.late_count = len(lines.filtered(lambda l: l.late_minutes > 0))
            sheet.late_minutes = sum(lines.mapped('late_minutes'))
            sheet.late_days = sum(lines.mapped('late_days'))
            sheet.early_minutes = sum(lines.mapped('early_minutes'))
            sheet.early_days = sum(lines.mapped('early_days'))
            sheet.absence_days = sum(lines.mapped('absence_days'))
            sheet.deduction_days = sheet.late_days + sheet.early_days + sheet.absence_days
            # overtime waiting for approval is shown on the lines but not counted
            paid = lines.filtered(lambda l: not l.ot_pending)
            for ot_type, _label in OT_TYPES:
                sheet[f'ot_{ot_type}_minutes'] = sum(paid.filtered(lambda l: l.ot_type == ot_type).mapped('ot_minutes'))
            sheet.ot_total_minutes = sum(paid.mapped('ot_minutes'))
            sheet.ot_pending_count = len(lines.filtered('ot_pending'))

    # ---------------------------------------------------------------- report helpers
    def _report_lang(self, summary=False):
        """Language of the printed sheet, as set in the attendance settings.

        A summary of several employees uses the language of the user unless a fixed language is set."""
        self.ensure_one()
        company = self.company_id
        if company.hik_report_lang == 'employee' and not summary and self.employee_id.sudo().lang:
            return self.employee_id.sudo().lang
        if company.hik_report_lang == 'fixed' and company.hik_report_lang_code:
            return company.hik_report_lang_code
        return self.env.lang or self.env.user.lang

    def _fmt_minutes(self, minutes):
        return format_minutes(minutes)

    def _fmt_days(self, days):
        _ = self.env._
        labels = {0.25: _('Quarter day'), 0.5: _('Half day'), 0.75: _('Three quarters of a day'),
                  1.0: _('One day'), 1.5: _('One and a half days'), 2.0: _('Two days')}
        if not days:
            return ''
        return labels.get(round(days, 4)) or _('%(days)s days', days=f'{days:g}')

    def _late_lines(self):
        return self.line_ids.filtered(lambda l: l.late_minutes or l.early_minutes or l.is_absent
                                      or l.deduction_days or l.missing_punch)

    def _ot_lines(self):
        return self.line_ids.filtered(lambda l: l.ot_minutes > 0)

    # ---------------------------------------------------------------- workflow
    def action_compute(self):
        for sheet in self:
            if sheet.state != 'draft':
                raise UserError(self.env._('A confirmed or locked sheet cannot be recomputed: set it back to draft first.'))
            sheet._compute_lines()

    def action_confirm(self):
        if self.filtered(lambda s: s.state != 'draft'):
            raise UserError(self.env._('Only draft sheets can be confirmed.'))
        self.write({'state': 'confirmed'})

    def action_done(self):
        if self.filtered(lambda s: s.state != 'confirmed'):
            raise UserError(self.env._('A sheet must be confirmed before being locked.'))
        self.write({'state': 'done'})

    def action_draft(self):
        if self.filtered(lambda s: s.state == 'done') and \
                not self.env.user.has_group('hr_attendance.group_hr_attendance_manager'):
            raise UserError(self.env._('Only an attendance administrator can reopen a locked sheet.'))
        self.write({'state': 'draft'})

    def action_approve_all_ot(self):
        self.line_ids.filtered('ot_pending').write({'ot_approved': True})

    def action_print_deductions(self):
        return self.env.ref('hik_attendance.action_report_hik_deductions').report_action(self)

    def action_print_summary(self):
        return self.env.ref('hik_attendance.action_report_hik_summary').report_action(self)

    def action_print_overtime(self):
        return self.env.ref('hik_attendance.action_report_hik_overtime').report_action(self)

    def unlink(self):
        if self.filtered(lambda s: s.state != 'draft'):
            raise UserError(self.env._('A confirmed or locked sheet cannot be deleted.'))
        return super().unlink()

    # ---------------------------------------------------------------- engine
    def _compute_lines(self):
        self.ensure_one()
        employee = self.employee_id
        policy = self.policy_id
        tz = pytz.timezone(employee._get_tz())
        today = datetime.now(tz).date()
        last_day = min(self.date_to, today - timedelta(days=1))

        def to_local(dt):
            return pytz.utc.localize(dt).astimezone(tz).replace(tzinfo=None)

        def to_utc(dt):
            return tz.localize(dt).astimezone(pytz.utc).replace(tzinfo=None)

        attendances = defaultdict(list)
        for att in self.env['hr.attendance'].search([
                ('employee_id', '=', employee.id), ('date', '>=', self.date_from), ('date', '<=', last_day)]):
            attendances[att.date].append(att)

        period_start = to_utc(datetime.combine(self.date_from, time.min))
        period_stop = to_utc(datetime.combine(last_day + timedelta(days=1), time.min))
        leaves = self.env['resource.calendar.leaves'].sudo().search([
            ('date_from', '<', period_stop), ('date_to', '>', period_start),
            ('company_id', 'in', [False, employee.company_id.id]),
            '|', ('resource_id', '=', employee.resource_id.id), ('resource_id', '=', False),
        ])
        personal = [(to_local(l.date_from), to_local(l.date_to)) for l in leaves if l.resource_id]

        existing = {line.date: line for line in self.line_ids}
        seen = set()
        Line = self.env['hik.attendance.sheet.line']
        day = self.date_from
        while day <= last_day:
            seen.add(day)
            version = employee._get_version(day).sudo()
            calendar = version.resource_calendar_id or employee.company_id.resource_calendar_id
            bounds = calendar_day_bounds(calendar, day)
            day_start, day_end = datetime.combine(day, time.min), datetime.combine(day, time.max)
            holidays = [(to_local(l.date_from), to_local(l.date_to)) for l in leaves
                        if not l.resource_id and l.calendar_id in (calendar, self.env['resource.calendar'])]

            def overlaps(intervals, start, end):
                return [(max(s, start), min(e, end)) for s, e in intervals if s < end and e > start]

            day_leaves = overlaps(personal, *bounds) if bounds else []
            if (version.contract_date_start and day < version.contract_date_start) or \
                    (version.contract_date_end and day > version.contract_date_end):
                day_type = 'out'
            elif overlaps(holidays, *(bounds or (day_start, day_end))):
                day_type = 'holiday'
            elif not bounds:
                day_type = 'weekly_off'
            elif day_leaves and self._covers(day_leaves, *bounds):
                day_type = 'leave'
            else:
                day_type = 'work'

            day_atts = attendances.get(day, [])
            check_in = to_local(min(a.check_in for a in day_atts)) if day_atts else None
            check_outs = [a.check_out for a in day_atts if a.check_out]
            check_out = to_local(max(check_outs)) if check_outs else None
            worked = sum(int((a.check_out - a.check_in).total_seconds() // 60) for a in day_atts if a.check_out)
            if check_out and check_in and worked == 0:
                check_out = check_in  # only single punches that day

            result = policy._evaluate_day(day, day_type, check_in, check_out, worked,
                                          day_leaves if day_type == 'work' else (), bounds)
            vals = dict(result, date=day, day_type=day_type,
                        check_in=to_utc(check_in) if check_in else False,
                        check_out=to_utc(check_out) if check_out and check_out != check_in else False,
                        worked_minutes=worked)
            if day in existing:
                existing[day].write(vals)
            else:
                Line.create(dict(vals, sheet_id=self.id))
            day += timedelta(days=1)

        self.line_ids.filtered(lambda l: l.date not in seen).unlink()
        free = policy.late_free_count
        for line in self.line_ids.sorted('date'):
            exempted = (line.late_days_auto > 0 and free > 0
                        and (not policy.late_free_max_minutes or line.late_minutes <= policy.late_free_max_minutes))
            line.late_free = exempted
            if exempted:
                free -= 1
        self.write(dict(self._eligibility(employee, last_day),
                        computed_until=last_day if last_day >= self.date_from else False))

    @api.model
    def _eligibility(self, employee, day):
        """Eligibility flags of the employee card, when a module adds them to the employee version."""
        version = employee._get_version(day).sudo()
        vals = {}
        if 'attendance_eligible' in version._fields:
            vals['apply_deductions'] = version.attendance_eligible
        if 'overtime_eligible' in version._fields:
            vals['apply_overtime'] = version.overtime_eligible
        return vals

    @staticmethod
    def _covers(intervals, start, end):
        cursor = start
        for s, e in sorted(intervals):
            if s > cursor:
                return False
            cursor = max(cursor, e)
        return cursor >= end

    @api.model
    def _hik_period(self, ref_date, company):
        start_day = min(max(company.hik_period_start_day or 1, 1), 28)
        if ref_date.day >= start_day:
            date_from = ref_date.replace(day=start_day)
        else:
            date_from = (ref_date.replace(day=1) - timedelta(days=1)).replace(day=start_day)
        date_to = (date_from + timedelta(days=32)).replace(day=start_day) - timedelta(days=1)
        return date_from, date_to

    @api.model
    def _cron_compute_drafts(self):
        for sheet in self.search([('state', '=', 'draft')]):
            sheet._compute_lines()


class HikAttendanceSheetLine(models.Model):
    _name = 'hik.attendance.sheet.line'
    _description = 'Attendance Sheet Day'
    _order = 'date'

    sheet_id = fields.Many2one('hik.attendance.sheet', required=True, ondelete='cascade', index=True)
    employee_id = fields.Many2one(related='sheet_id.employee_id', store=True, string='Employee')
    department_id = fields.Many2one(related='sheet_id.department_id', store=True, string='Department')
    sheet_state = fields.Selection(related='sheet_id.state', string='Sheet Status')
    date = fields.Date('Date', required=True)
    weekday = fields.Char('Day', compute='_compute_weekday')
    day_type = fields.Selection(DAY_TYPES, string='Day Type', readonly=True)
    check_in = fields.Datetime('Check In', readonly=True)
    check_out = fields.Datetime('Check Out', readonly=True)
    worked_minutes = fields.Integer('Time Present (minutes)', readonly=True)
    missing_punch = fields.Boolean('Missing Punch', readonly=True)
    auto_note = fields.Selection(AUTO_NOTES, string='System Note', readonly=True)

    late_minutes = fields.Integer('Late Minutes', readonly=True)
    late_days_auto = fields.Float('Computed Late Deduction (days)', readonly=True, digits=(16, 4))
    late_free = fields.Boolean('Late Exemption', readonly=True)
    early_minutes = fields.Integer('Early Leave Minutes', readonly=True)
    early_days_auto = fields.Float('Computed Early Leave Deduction (days)', readonly=True, digits=(16, 4))
    absence_days_auto = fields.Float('Computed Absence Deduction (days)', readonly=True, digits=(16, 4))
    ot_type = fields.Selection(OT_TYPES, string='Overtime Type', readonly=True)
    ot_minutes_auto = fields.Integer('Computed Overtime (minutes)', readonly=True)

    # manual adjustments, kept when the sheet is recomputed
    waive_deduction = fields.Boolean('Cancel Deduction')
    waive_reason = fields.Char('Adjustment Reason')
    ot_manual = fields.Boolean('Manual Overtime')
    ot_minutes_manual = fields.Integer('Approved Overtime (minutes)')
    ot_approved = fields.Boolean('Overtime Approved')

    is_absent = fields.Boolean('Absent', compute='_compute_amounts', store=True)
    late_days = fields.Float('Late Deduction (days)', compute='_compute_amounts', store=True, digits=(16, 4))
    early_days = fields.Float('Early Leave Deduction (days)', compute='_compute_amounts', store=True, digits=(16, 4))
    absence_days = fields.Float('Absence Deduction (days)', compute='_compute_amounts', store=True, digits=(16, 4))
    deduction_days = fields.Float('Day Deduction (days)', compute='_compute_amounts', store=True, digits=(16, 4))
    ot_minutes = fields.Integer('Overtime (minutes)', compute='_compute_amounts', store=True)
    ot_pending = fields.Boolean('Waiting for Approval', compute='_compute_amounts', store=True)

    _unique_day = models.Constraint('UNIQUE(sheet_id, date)', 'This day is already on the sheet.')

    @api.depends('date')
    @api.depends_context('lang')
    def _compute_weekday(self):
        locale = babel_locale_parse(self.env.lang or 'en_US')
        for line in self:
            line.weekday = babel_format_date(line.date, 'EEEE', locale=locale) if line.date else False

    @api.depends('late_days_auto', 'late_free', 'early_days_auto', 'absence_days_auto', 'waive_deduction',
                 'ot_type', 'ot_minutes_auto', 'ot_manual', 'ot_minutes_manual',
                 'ot_approved', 'sheet_id.policy_id.ot_requires_approval',
                 'sheet_id.apply_deductions', 'sheet_id.apply_overtime')
    def _compute_amounts(self):
        for line in self:
            waived = line.waive_deduction or not line.sheet_id.apply_deductions
            line.is_absent = line.absence_days_auto > 0
            line.late_days = 0.0 if waived or line.late_free else line.late_days_auto
            line.early_days = 0.0 if waived else line.early_days_auto
            line.absence_days = 0.0 if waived else line.absence_days_auto
            line.deduction_days = line.late_days + line.early_days + line.absence_days
            minutes = line.ot_minutes_manual if line.ot_manual else line.ot_minutes_auto
            line.ot_minutes = minutes if line.ot_type and line.sheet_id.apply_overtime else 0
            needs_approval = line.sheet_id.policy_id.ot_requires_approval
            line.ot_pending = bool(line.ot_minutes and needs_approval and not line.ot_approved)

    def write(self, vals):
        manual = {'waive_deduction', 'waive_reason', 'ot_manual', 'ot_minutes_manual', 'ot_approved'}
        if manual & set(vals) and self.filtered(lambda l: l.sheet_id.state == 'done'):
            raise UserError(self.env._('This sheet is locked and cannot be changed.'))
        return super().write(vals)

    def _fmt_minutes(self, minutes):
        return format_minutes(minutes)

    def _fmt_time(self, value):
        """HH:MM in the employee's timezone, whatever the timezone of the user printing the report."""
        if not value:
            return ''
        tz = pytz.timezone(self.employee_id._get_tz())
        return pytz.utc.localize(value).astimezone(tz).strftime('%H:%M')
