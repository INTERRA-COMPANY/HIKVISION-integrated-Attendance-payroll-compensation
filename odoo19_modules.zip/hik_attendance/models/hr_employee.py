from odoo import api, fields, models
from odoo.exceptions import UserError, ValidationError

from .isapi_client import IsapiError


class HrEmployee(models.Model):
    _inherit = 'hr.employee'

    hik_employee_no = fields.Char(
        'Device Employee No.', copy=False, tracking=True,
        help='Employee No. of this employee on the Hikvision device.')
    hik_policy_id = fields.Many2one(
        'hik.attendance.policy', string='Attendance Policy', tracking=True)

    @api.constrains('hik_employee_no', 'company_id')
    def _check_hik_employee_no(self):
        for employee in self.filtered('hik_employee_no'):
            duplicate = self.with_context(active_test=False).search([
                ('id', '!=', employee.id), ('company_id', '=', employee.company_id.id),
                ('hik_employee_no', '=', employee.hik_employee_no)], limit=1)
            if duplicate:
                raise ValidationError(self.env._(
                    'Device employee no. %(number)s is already used by %(employee)s.',
                    number=employee.hik_employee_no, employee=duplicate.name))

    @api.model_create_multi
    def create(self, vals_list):
        employees = super().create(vals_list)
        employees.filtered('hik_policy_id')._hik_policy_setup()
        return employees

    def _hik_policy_setup(self):
        """The attendance policy computes the overtime and the deductions:
        - give the employees an Odoo overtime ruleset without rules, so Odoo does not compute a second,
          different overtime for them;
        - generate their work entries from the working schedule, so the payslip pays the full basic salary
          and the attendance sheet alone deducts the late arrivals and absences (with work entries from the
          attendances, the payslip would pay the attended hours and deduct twice)."""
        versions = self.sudo().version_ids
        ruleset = self.env.ref('hik_attendance.ruleset_policy_overtime', raise_if_not_found=False)
        if ruleset:
            versions.filtered(lambda v: v.ruleset_id != ruleset).write({'ruleset_id': ruleset.id})
        if 'work_entry_source' in versions._fields:
            versions.filtered(lambda v: v.work_entry_source != 'calendar').write({'work_entry_source': 'calendar'})

    def _hik_devices(self):
        return self.env['hik.device'].search([('company_id', 'in', self.company_id.ids)])

    def action_hik_push_to_devices(self):
        """Create/update the selected employees on the devices (the face is enrolled on the device itself)."""
        missing = self.filtered(lambda e: not e.hik_employee_no)
        if missing:
            raise UserError(self.env._('These employees have no device employee no.: %s', ', '.join(missing.mapped('name'))))
        for device in self._hik_devices():
            for employee in self.filtered(lambda e: e.company_id == device.company_id):
                try:
                    device._push_employee(employee)
                except IsapiError as e:
                    raise UserError(f'{device.name} / {employee.name}: {device._isapi_message(e)}')
        return self.env['hik.device']._notify(
            self.env._('Employees sent to the device. Enroll the face or fingerprint on the device itself.'), 'success')

    def write(self, vals):
        archived_before = self.filtered(lambda e: not e.active)
        res = super().write(vals)
        if vals.get('hik_policy_id'):
            self._hik_policy_setup()
        if vals.get('active') is False:
            for employee in self - archived_before:
                employee._hik_remove_from_devices()
        return res

    def _hik_remove_from_devices(self):
        self.ensure_one()
        employee_no = self.sudo().hik_employee_no
        if not employee_no:
            return
        for device in self._hik_devices().filtered('remove_archived_employees'):
            try:
                device._remove_employee_no(employee_no)
                device.message_post(body=self.env._(
                    '%(employee)s (no. %(number)s) removed from the device after being archived.',
                    employee=self.name, number=employee_no))
            except IsapiError as e:
                device.message_post(body=self.env._(
                    'Could not remove %(employee)s (no. %(number)s) from the device: %(error)s',
                    employee=self.name, number=employee_no, error=device._isapi_message(e)))
