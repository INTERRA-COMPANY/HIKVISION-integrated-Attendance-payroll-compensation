import logging
from datetime import datetime, timedelta

import pytz

from odoo import api, fields, models
from odoo.exceptions import UserError

from .isapi_client import IsapiClient, IsapiError, parse_isapi_time

_logger = logging.getLogger(__name__)


def _tz_selection(self):
    return [(tz, tz) for tz in pytz.common_timezones]


class HikDevice(models.Model):
    _name = 'hik.device'
    _description = 'Hikvision Device'
    _inherit = ['mail.thread']

    name = fields.Char('Device Name', required=True)
    active = fields.Boolean(default=True)
    company_id = fields.Many2one('res.company', string='Company', required=True, default=lambda self: self.env.company)
    host = fields.Char('IP Address', required=True, tracking=True)
    port = fields.Integer('Port', default=80, required=True)
    use_https = fields.Boolean('HTTPS')
    username = fields.Char('Device Username', required=True, default='admin')
    password = fields.Char('Device Password', groups='hr_attendance.group_hr_attendance_manager')
    tz = fields.Selection(_tz_selection, string='Device Timezone', required=True,
                          default=lambda self: self.env.user.tz or 'Africa/Cairo')
    event_minors = fields.Char(
        'Event Codes', default='0', required=True,
        help='0 = all authentication events. If the device refuses it, list the codes separated by commas: '
             '75 face, 38 fingerprint, 1 card.')
    min_punch_gap = fields.Integer(
        'Minimum Check-in/Check-out Gap (minutes)', default=2,
        help='When the first and last punch of the day are closer than this, they count as one punch (duplicate).')
    sync_from = fields.Datetime('Import Punches From', required=True,
                                default=lambda self: fields.Datetime.now().replace(day=1, hour=0, minute=0, second=0))
    last_event_time = fields.Datetime('Last Imported Punch', readonly=True)
    last_sync = fields.Datetime('Last Successful Sync', readonly=True)
    state = fields.Selection([('new', 'Not Tested'), ('ok', 'Connected'), ('error', 'Error')],
                             string='Status', default='new', readonly=True, tracking=True)
    last_error = fields.Text('Last Error', readonly=True)
    device_model = fields.Char('Model', readonly=True)
    serial_number = fields.Char('Serial Number', readonly=True)
    firmware = fields.Char('Firmware', readonly=True)
    replace_other_attendances = fields.Boolean(
        'Device Is the Only Attendance Source', default=True,
        help='On a day with punches, attendances recorded another way (manually, kiosk, other integrations) are '
             'replaced by the device attendance, so each employee has a single attendance per day. '
             'To correct a day, edit the device attendance instead of adding a new one.')
    remove_archived_employees = fields.Boolean(
        'Remove Archived Employees from the Device', default=True,
        help='An employee archived in Odoo (left the company) is deleted from the device and can no longer punch.')
    log_count = fields.Integer(compute='_compute_log_count')

    def _compute_log_count(self):
        counts = dict(self.env['hik.attendance.log']._read_group(
            [('device_id', 'in', self.ids)], ['device_id'], ['__count']))
        for device in self:
            device.log_count = counts.get(device, 0)

    def _client(self):
        self.ensure_one()
        return IsapiClient(self.host, self.port, self.username, self.sudo().password or '', self.use_https)

    def _isapi_message(self, error):
        """Translated text of an IsapiError."""
        _ = self.env._
        params = error.params
        if error.kind == 'connection':
            return _('Cannot reach the device %(url)s: %(error)s', **params)
        if error.kind == 'auth':
            return _('Wrong device username or password (401).')
        if error.kind == 'http':
            return _('The device answered with error %(status)s: %(detail)s', **params)
        return _('Unexpected answer of the device on %(path)s', **params)

    def _set_error(self, error):
        message = self._isapi_message(error)
        self.write({'state': 'error', 'last_error': message})
        self.message_post(body=self.env._('Connection to the device failed: %s', message))
        return message

    # ---------------------------------------------------------------- buttons
    def action_test_connection(self):
        self.ensure_one()
        try:
            client = self._client()
            info = client.device_info()
            device_time = client.device_time()
        except IsapiError as e:
            raise UserError(self._set_error(e))
        self.write({
            'state': 'ok', 'last_error': False,
            'device_model': info.get('model'), 'serial_number': info.get('serialNumber'),
            'firmware': info.get('firmwareVersion'),
        })
        _ = self.env._
        message = _('Connected to the device %s.', info.get('model', ''))
        kind = 'success'
        if device_time:
            drift = abs((device_time - datetime.now(pytz.utc)).total_seconds())
            if drift > 60:
                kind = 'warning'
                message += ' ' + _('Warning: the device clock is about %s minutes off the server, enable NTP on the device.',
                                   int(drift // 60))
            else:
                message += ' ' + _('The device clock is correct.')
        return self._notify(message, kind)

    def action_sync_now(self):
        count = 0
        for device in self:
            try:
                count += device._sync_events()
            except IsapiError as e:
                raise UserError(device._set_error(e))
        self.env['hik.attendance.log']._process_pending()
        return self._notify(self.env._('%s new punches imported.', count), 'success')

    def action_view_logs(self):
        return {
            'type': 'ir.actions.act_window', 'name': self.env._('Raw Punches'), 'res_model': 'hik.attendance.log',
            'view_mode': 'list,form', 'domain': [('device_id', '=', self.id)],
        }

    def action_import_users(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window', 'name': self.env._('Link Device Users to Employees'),
            'res_model': 'hik.import.users', 'view_mode': 'form', 'target': 'new',
            'context': {'default_device_id': self.id},
        }

    @staticmethod
    def _notify(message, kind):
        return {'type': 'ir.actions.client', 'tag': 'display_notification',
                'params': {'message': message, 'type': kind, 'sticky': False}}

    # ---------------------------------------------------------------- sync
    def _sync_events(self):
        """Pull new events from the device into hik.attendance.log. Returns the number of new logs."""
        self.ensure_one()
        tz = pytz.timezone(self.tz)
        since = self.last_event_time - timedelta(minutes=30) if self.last_event_time else self.sync_from
        start = pytz.utc.localize(since).astimezone(tz)
        end = datetime.now(tz) + timedelta(minutes=5)
        client = self._client()
        Log = self.env['hik.attendance.log']
        candidates = {}
        minors = [int(m) for m in self.event_minors.replace(' ', '').split(',') if m]
        for minor in minors:
            for event in client.iter_events(start, end, minor=minor):
                employee_no = str(event.get('employeeNoString') or event.get('employeeNo') or '').strip()
                if not employee_no or not event.get('time'):
                    continue
                punch = parse_isapi_time(event['time'], tz).astimezone(pytz.utc).replace(tzinfo=None)
                candidates.setdefault((employee_no, punch), {
                    'device_id': self.id, 'employee_no': employee_no, 'punch_time': punch,
                    'device_user_name': event.get('name'), 'event_minor': event.get('minor'),
                    'verify_mode': event.get('currentVerifyMode'), 'serial_no': event.get('serialNo'),
                })
        newest = self.last_event_time
        vals_list = []
        if candidates:
            times = [punch for _no, punch in candidates]
            existing = set(Log.search([
                ('device_id', '=', self.id), ('punch_time', '>=', min(times)), ('punch_time', '<=', max(times)),
            ]).mapped(lambda l: (l.employee_no, l.punch_time)))
            vals_list = [vals for key, vals in candidates.items() if key not in existing]
            newest = max([newest, *times]) if newest else max(times)
        Log.create(vals_list)
        self.write({'last_event_time': newest, 'last_sync': fields.Datetime.now(), 'state': 'ok', 'last_error': False})
        return len(vals_list)

    @api.model
    def _cron_sync(self):
        for device in self.search([]):
            try:
                device._sync_events()
                self.env.cr.commit()
            except IsapiError as e:
                self.env.cr.rollback()
                if device.state != 'error':
                    device._set_error(e)
                else:
                    device.last_error = device._isapi_message(e)
                self.env.cr.commit()
            except Exception:
                self.env.cr.rollback()
                _logger.exception('Hikvision sync failed for device %s', device.id)
        self.env['hik.attendance.log']._process_pending()
        self.env['hr.attendance']._hik_close_stale()

    # ---------------------------------------------------------------- users
    def _push_employee(self, employee):
        self._client().upsert_user(employee.hik_employee_no, employee.name)

    def _remove_employee_no(self, employee_no):
        self._client().delete_user(employee_no)
