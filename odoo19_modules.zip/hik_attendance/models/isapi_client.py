"""Minimal client for the Hikvision ISAPI protocol (access-control terminals).

Kept free of any Odoo import so it can be unit-tested and reused on its own.
"""
import json
import logging
import uuid
from datetime import datetime
from xml.etree import ElementTree

import requests
from requests.auth import HTTPDigestAuth

_logger = logging.getLogger(__name__)

PAGE_SIZE = 30  # most terminals refuse more than 30 records per page


class IsapiError(Exception):
    """``kind`` is one of: connection, auth, http, unexpected. ``params`` hold the details."""

    def __init__(self, kind, **params):
        self.kind = kind
        self.params = params
        super().__init__(f'{kind}: {params}')


def _strip_ns(tag):
    return tag.split('}', 1)[-1]


def xml_to_dict(text):
    """Flatten a simple ISAPI XML answer into {tag: text}."""
    root = ElementTree.fromstring(text)
    return {_strip_ns(el.tag): (el.text or '').strip() for el in root.iter() if len(el) == 0}


def format_isapi_time(dt):
    """Aware datetime -> '2026-10-01T08:00:00+03:00' (the offset must contain a colon)."""
    value = dt.strftime('%Y-%m-%dT%H:%M:%S%z')
    return value[:-2] + ':' + value[-2:]


def parse_isapi_time(value, fallback_tz):
    """ISAPI time string -> aware datetime. Naive values are assumed to be in fallback_tz."""
    dt = datetime.fromisoformat(value.strip().replace('Z', '+00:00'))
    if dt.tzinfo is None:
        dt = fallback_tz.localize(dt)
    return dt


class IsapiClient:

    def __init__(self, host, port=80, username='', password='', use_https=False, timeout=20, verify_ssl=False):
        scheme = 'https' if use_https else 'http'
        self.base_url = f'{scheme}://{host}:{port}'
        self.auth = HTTPDigestAuth(username, password)
        self.timeout = timeout
        self.verify_ssl = verify_ssl

    # ------------------------------------------------------------------ low level
    def _request(self, method, path, payload=None):
        url = self.base_url + path
        try:
            response = requests.request(
                method, url, auth=self.auth, timeout=self.timeout, verify=self.verify_ssl,
                data=json.dumps(payload) if payload is not None else None,
                headers={'Content-Type': 'application/json'} if payload is not None else None,
            )
        except requests.RequestException as e:
            raise IsapiError('connection', url=self.base_url, error=str(e)) from e
        if response.status_code == 401:
            raise IsapiError('auth')
        if response.status_code >= 400:
            raise IsapiError('http', status=response.status_code, detail=self._error_detail(response))
        return response

    @staticmethod
    def _error_detail(response):
        detail = response.text[:300]
        try:
            data = response.json()
            detail = data.get('errorMsg') or data.get('subStatusCode') or data.get('statusString') or detail
        except ValueError:
            try:
                xml = xml_to_dict(response.text)
                detail = xml.get('subStatusCode') or xml.get('statusString') or detail
            except ElementTree.ParseError:
                pass
        return detail

    def _json(self, method, path, payload=None):
        response = self._request(method, path, payload)
        try:
            return response.json()
        except ValueError as e:
            raise IsapiError('unexpected', path=path) from e

    # ------------------------------------------------------------------ device
    def device_info(self):
        return xml_to_dict(self._request('GET', '/ISAPI/System/deviceInfo').text)

    def device_time(self):
        """Return the device clock as an aware datetime (or None if unreadable)."""
        data = xml_to_dict(self._request('GET', '/ISAPI/System/time').text)
        value = data.get('localTime')
        if not value:
            return None
        dt = datetime.fromisoformat(value)
        return dt if dt.tzinfo else None

    # ------------------------------------------------------------------ events
    def iter_events(self, start, end, minor=0, major=5):
        """Yield access-control events between two aware datetimes."""
        search_id = uuid.uuid4().hex
        position = 0
        while True:
            data = self._json('POST', '/ISAPI/AccessControl/AcsEvent?format=json', {
                'AcsEventCond': {
                    'searchID': search_id,
                    'searchResultPosition': position,
                    'maxResults': PAGE_SIZE,
                    'major': major,
                    'minor': minor,
                    'startTime': format_isapi_time(start),
                    'endTime': format_isapi_time(end),
                },
            })
            result = data.get('AcsEvent') or {}
            items = result.get('InfoList') or []
            yield from items
            position += len(items)
            if result.get('responseStatusStrg') != 'MORE' or not items:
                break

    # ------------------------------------------------------------------ users
    def iter_users(self):
        search_id = uuid.uuid4().hex
        position = 0
        while True:
            data = self._json('POST', '/ISAPI/AccessControl/UserInfo/Search?format=json', {
                'UserInfoSearchCond': {
                    'searchID': search_id,
                    'searchResultPosition': position,
                    'maxResults': PAGE_SIZE,
                },
            })
            result = data.get('UserInfoSearch') or {}
            items = result.get('UserInfo') or []
            yield from items
            position += len(items)
            if result.get('responseStatusStrg') != 'MORE' or not items:
                break

    def upsert_user(self, employee_no, name):
        user = {
            'employeeNo': str(employee_no),
            'name': name[:32],
            'userType': 'normal',
            'Valid': {
                'enable': True,
                'beginTime': '2020-01-01T00:00:00',
                'endTime': '2037-12-31T23:59:59',
                'timeType': 'local',
            },
            'doorRight': '1',
            'RightPlan': [{'doorNo': 1, 'planTemplateNo': '1'}],
        }
        try:
            self._json('POST', '/ISAPI/AccessControl/UserInfo/Record?format=json', {'UserInfo': user})
        except IsapiError as e:
            if 'employeeNoAlreadyExist' not in str(e.params.get('detail', '')):
                raise
            self._json('PUT', '/ISAPI/AccessControl/UserInfo/Modify?format=json', {'UserInfo': user})

    def delete_user(self, employee_no):
        self._json('PUT', '/ISAPI/AccessControl/UserInfoDetail/Delete?format=json', {
            'UserInfoDetail': {
                'mode': 'byEmployeeNo',
                'EmployeeNoList': [{'employeeNo': str(employee_no)}],
            },
        })
