from odoo import SUPERUSER_ID, api


def migrate(cr, version):
    env = api.Environment(cr, SUPERUSER_ID, {})
    env['hr.employee'].with_context(active_test=False).search([('hik_policy_id', '!=', False)])._hik_policy_setup()
